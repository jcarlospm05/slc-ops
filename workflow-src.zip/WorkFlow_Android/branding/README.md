# WorkFlow · identidad visual

Icono en SVG original (`workflow_icon.svg`) y PNG 1024 para entrega.
`assets/branding/workflow_icon.png`: identidad interna de Flutter.
`android/app/src/main/res`: iconos launcher y adaptive.
El pipeline GitHub copia estos recursos después de regenerar Android.
