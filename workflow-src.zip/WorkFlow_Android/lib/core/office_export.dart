import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'backup_service.dart';
import 'catalog.dart';
import 'reporting.dart';
import 'pdf_export.dart';
import 'security.dart';

class OfficeExport {
  static Future<Uint8List> pdf(OpsReport report)=>PdfExport.build(report);
  static Uint8List _zip(Map<String,Uint8List> files){
    final a=Archive();
    files.forEach((name,data)=>a.addFile(ArchiveFile(name,data.length,data)));
    return Uint8List.fromList(ZipEncoder().encode(a));
  }
  static Uint8List _zipText(Map<String,String> files,[Map<String,Uint8List> raw=const {}]){
    final all=<String,Uint8List>{for(final e in files.entries)e.key:Uint8List.fromList(utf8.encode(e.value)),...raw};
    return _zip(all);
  }
  static String _cell(int col,int row,Object? value){
    var x=col;var letters='';do{letters=String.fromCharCode(65+x%26)+letters;x=x~/26-1;}while(x>=0);
    // All cells are safe literal inline strings; NEVER interpret external formulas.
    return '<c r="$letters$row" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(officeCell(value))}</t></is></c>';
  }
  static String _sheet(List<List<Object?>> rows,{bool chart=false}){
    final xml=StringBuffer('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="18"/><sheetData>''');
    for(var y=0;y<rows.length;y++){
      xml.write('<row r="${y+1}">');
      for(var x=0;x<rows[y].length;x++){xml.write(_cell(x,y+1,rows[y][x]));}
      xml.write('</row>');
    }
    xml.write('</sheetData>');
    if(chart)xml.write('<drawing r:id="rId1"/>');
    xml.write('</worksheet>');
    return xml.toString();
  }
  static Uint8List xlsx(OpsReport r){
    final data=<List<Object?>>[r.headers,...r.rows];
    final values=<List<Object?>>[['Indicador','Valor'],...r.metrics.entries.map((e)=>[e.key,e.value.toStringAsFixed(2)])];
    if(values.length==1)values.add(['Sin registros','0']);
    final last=values.length;
    final chart='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:chart><c:plotArea><c:layout/><c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:ser><c:idx val="0"/><c:order val="0"/><c:tx><c:v>Cantidad / horas</c:v></c:tx><c:cat><c:strRef><c:f>Indicadores!\$A\$2:\$A\$$last</c:f><c:strCache><c:ptCount val="${last-1}"/>${r.metrics.isEmpty?'<c:pt idx="0"><c:v>Sin registros</c:v></c:pt>':r.metrics.keys.toList().asMap().entries.map((e)=>'<c:pt idx="${e.key}"><c:v>${xmlEscape(e.value)}</c:v></c:pt>').join()}</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Indicadores!\$B\$2:\$B\$$last</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="${last-1}"/>${r.metrics.isEmpty?'<c:pt idx="0"><c:v>0</c:v></c:pt>':r.metrics.values.toList().asMap().entries.map((e)=>'<c:pt idx="${e.key}"><c:v>${e.value}</c:v></c:pt>').join()}</c:numCache></c:numRef></c:val></c:ser><c:axId val="11"/><c:axId val="12"/></c:barChart><c:catAx><c:axId val="11"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="b"/><c:crossAx val="12"/><c:crosses val="autoZero"/></c:catAx><c:valAx><c:axId val="12"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="l"/><c:crossAx val="11"/><c:crosses val="autoZero"/></c:valAx></c:plotArea><c:plotVisOnly val="1"/></c:chart></c:chartSpace>''';
    final d='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><xdr:twoCellAnchor><xdr:from><xdr:col>3</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>1</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>14</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>22</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="2" name="Gráfico WorkFlow"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId1"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>''';
    return _zipText({
      '[Content_Types].xml':'''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/charts/chart1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>''',
      '_rels/.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>''',
      'xl/workbook.xml':'''<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Datos" sheetId="1" r:id="rId1"/><sheet name="Indicadores" sheetId="2" r:id="rId2"/></sheets></workbook>''',
      'xl/_rels/workbook.xml.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>''',
      'xl/worksheets/sheet1.xml':_sheet(data),
      'xl/worksheets/sheet2.xml':_sheet(values,chart:true),
      'xl/worksheets/_rels/sheet2.xml.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>''',
      'xl/drawings/drawing1.xml':d,
      'xl/drawings/_rels/drawing1.xml.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart1.xml"/></Relationships>''',
      'xl/charts/chart1.xml':chart,
    });
  }

  static void _caption(ui.Canvas canvas,String text,double x,double y,{double size=20,ui.Color color=const ui.Color(0xFF16355A),double width=200}){
    final pb=ui.ParagraphBuilder(ui.ParagraphStyle(fontSize:size,maxLines:2))
      ..pushStyle(ui.TextStyle(color:color,fontSize:size,fontWeight:ui.FontWeight.w500))
      ..addText(text);
    final p=pb.build()..layout(ui.ParagraphConstraints(width:width));
    canvas.drawParagraph(p,ui.Offset(x,y));
  }
  static Future<Uint8List> _chartPng(Map<String,double> data) async {
    const w=960.0,h=420.0;
    final recorder=ui.PictureRecorder();
    final canvas=ui.Canvas(recorder);
    canvas.drawColor(const ui.Color(0xFFFFFFFF),ui.BlendMode.src);
    _caption(canvas,'Resumen de indicadores',35,15,size:28,width:800);
    final items=(data.isEmpty?{'Sin registros':0.0}:data).entries.take(8).toList();
    final max=items.map((e)=>e.value).fold<double>(1,(a,b)=>b>a?b:a);
    for(var i=0;i<items.length;i++){
      final y=74.0+i*41;
      _caption(canvas,items[i].key,20,y+2,size:15,width:220);
      final value=items[i].value;
      canvas.drawRRect(ui.RRect.fromRectAndRadius(ui.Rect.fromLTWH(245,y,570*value/max,26),const ui.Radius.circular(5)),ui.Paint()..color=const ui.Color(0xFF2563EB));
      _caption(canvas,value.toStringAsFixed(value==value.roundToDouble()?0:1),830,y+3,size:15,width:120);
    }
    final pic=recorder.endRecording();
    final img=await pic.toImage(w.toInt(),h.toInt());
    final bytes=await img.toByteData(format:ui.ImageByteFormat.png);
    img.dispose();pic.dispose();
    if(bytes==null)throw StateError('No se pudo crear el gráfico');
    return bytes.buffer.asUint8List();
  }
  static String _paragraph(Object? text,{bool bold=false})=>'<w:p><w:r>${bold?'<w:rPr><w:b/></w:rPr>':''}<w:t xml:space="preserve">${xmlEscape(officeCell(text))}</w:t></w:r></w:p>';
  static String _table(List<List<Object?>> rows){
    final b=StringBuffer('<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/></w:tblPr>');
    for(final row in rows.take(401)){
      b.write('<w:tr>');
      for(final cell in row.take(12)){b.write('<w:tc><w:tcPr><w:tcW w:w="1900" w:type="dxa"/></w:tcPr>${_paragraph(cell)}</w:tc>');}
      b.write('</w:tr>');
    }
    b.write('</w:tbl>');return b.toString();
  }
  static Future<Uint8List> docx(OpsReport report)async{
    final png=await _chartPng(report.metrics);
    final picture='''<w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0"><wp:extent cx="6096000" cy="2667000"/><wp:docPr id="1" name="Gráfico WorkFlow"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="chart.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="6096000" cy="2667000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>''';
    final doc='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>${_paragraph('Departamento de Operaciones · WorkFlow',bold:true)}${_paragraph(report.title,bold:true)}${_paragraph('Período: ${prettyDate(report.from)} a ${prettyDate(report.to)}')}$picture${_table([report.headers,...report.rows])}<w:p/><w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900"/></w:sectPr></w:body></w:document>''';
    return _zipText({
      '[Content_Types].xml':'''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>''',
      '_rels/.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''',
      'word/document.xml':doc,
      'word/_rels/document.xml.rels':'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/chart.png"/></Relationships>''',
    },{'word/media/chart.png':png});
  }
  static Uint8List csv(OpsReport report){
    final content='\uFEFF${[report.headers,...report.rows].map((r)=>r.map(csvCell).join(';')).join('\r\n')}';
    return Uint8List.fromList(utf8.encode(content));
  }
  static Future<File> save(String name,Uint8List content)async{
    final root=await getApplicationDocumentsDirectory();
    final dir=Directory(p.join(root.path,'WorkFlow','reportes'));
    await dir.create(recursive:true);
    final safe=name.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'),'_');
    final file=File(p.join(dir.path,safe));
    return file.writeAsBytes(content,flush:true);
  }
  static Future<File> backup(Map<String,List<Map<String,dynamic>>> data)async{
    return save('WorkFlow_backup_${DateTime.now().millisecondsSinceEpoch}.json',BackupService.encode(data));
  }
}
