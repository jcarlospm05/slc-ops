import 'catalog.dart';

class OpsReport {
  OpsReport({required this.title,required this.headers,required this.rows,required this.metrics,required this.from,required this.to});
  final String title,from,to;
  final List<String> headers;
  final List<List<Object?>> rows;
  final Map<String,double> metrics;
}
class ReportEngine {
  static const types=<String,String>{
    'asistencia':'Asistencia detallada','asistencia_resumen':'Conteo de asistencia',
    'tickets':'Infracciones emitidas','daysOff':'Días libres',
    'schedules':'Programación de operadores','meals':'Solicitudes de comidas',
    'faults':'Averías y tiempo fuera','operators':'Maestro de operadores',
    'assets':'Maestro de equipos',
    'cierre_diario':'Cierre operacional diario',
  };
  static OpsReport make(Map<String,List<Map<String,dynamic>>> db,String type,String from,String to){
    if(!types.containsKey(type))throw ArgumentError('Tipo de reporte desconocido');
    if(type=='cierre_diario')return dailyClose(db,from);
    final operators={for(final o in db['operators']??[])o['id']:'${o['name']}'};
    final assets={for(final a in db['assets']??[])a['id']:'${a['code']}'};
    final all=(db[type=='asistencia_resumen'?'attendance':type]??[]).where((r){
      if(type=='operators'||type=='assets')return true;
      final date='${r['date']??r['start']??''}';
      return date.compareTo(from)>=0 && date.compareTo('${to}T99')<=0;
    }).toList();
    List<String> h=[];
    List<List<Object?>> rows=[];
    Map<String,double> metrics={};
    String op(Map r)=>operators[r['operatorId']]??'No registrado';
    String asset(Map r)=>assets[r['assetId']]??'No registrado';
    if(type=='asistencia'){
      h=['Fecha','Operador','Marcación','Inicio','Fin','Observaciones'];
      rows=all.map((r)=>[r['date'],op(r),attendanceStates[r['status']]??r['status'],r['start'],r['end'],r['notes']]).toList();
      for(final r in all){final k=attendanceStates[r['status']]??'Sin marcar';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='asistencia_resumen'){
      h=['Operador','Presentes','Tardanzas','Aus. just.','Aus. injust.','Libres','Total'];
      for(final o in (db['operators']??[])){
        final own=all.where((a)=>a['operatorId']==o['id']);
        int n(String s)=>own.where((a)=>a['status']==s).length;
        rows.add([o['name'],n('PRESENTE'),n('TARDANZA'),n('AUSENTE_JUST'),n('AUSENTE_INJUST'),n('LIBRE'),own.length]);
      }
      metrics={'Presente':all.where((e)=>e['status']=='PRESENTE').length.toDouble(),
        'Tardanza':all.where((e)=>e['status']=='TARDANZA').length.toDouble(),
        'Injustificada':all.where((e)=>e['status']=='AUSENTE_INJUST').length.toDouble(),
        'Justificada':all.where((e)=>e['status']=='AUSENTE_JUST').length.toDouble(),
        'Libre':all.where((e)=>e['status']=='LIBRE').length.toDouble()};
    } else if(type=='tickets'){
      h=['Fecha','Operador','Motivo','Nivel','Estado','Supervisor','Objetivo','Real','Reincidencias','Descripción'];
      rows=all.map((r)=>[r['date'],op(r),ticketReasons[r['reason']]??r['reason'],r['level'],r['status'],r['supervisor'],r['expected'],r['actual'],r['reincidences']??0,r['description']]).toList();
      for(final r in all){final k=ticketReasons[r['reason']]??'Otro';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='daysOff'){
      h=['Fecha','Operador','Motivo','Observaciones'];rows=all.map((r)=>[r['date'],op(r),r['type'],r['notes']]).toList();
      for(final r in all){final k='${r['type']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='schedules'){
      h=['Fecha','Operador','Inicio','Fin','Tarea','Equipo','Área'];
      rows=all.map((r)=>[r['date'],op(r),r['start'],r['end'],r['task'],r['assetId']==null||r['assetId']==''?'':asset(r),r['place']]).toList();
      for(final r in all){final k= '${r['task']??'Sin tarea'}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='meals'){
      h=['Fecha','Operador','Servicio','Observaciones'];
      rows=all.map((r)=>[r['date'],op(r),r['type'],r['notes']]).toList();
      for(final r in all){final k='${r['type']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='faults'){
      h=['Equipo','Inicio','Fin','Horas fuera','Avería','Solución'];
      rows=all.map((r){final s=DateTime.tryParse('${r['start']??''}');final e=DateTime.tryParse('${r['end']??''}')??DateTime.now();
        final hours=(s==null?0.0:(e.difference(s).inMinutes/60).clamp(0.0,100000.0)).toDouble();
        final key=asset(r);metrics[key]=(metrics[key]??0)+hours;
        return [keyOr(r,assets),r['start'],r['end']??'Abierta',hours.toStringAsFixed(2),r['description'],r['notes']];
      }).toList();
    } else if(type=='operators'){
      h=['Ficha','Operador','Categoría','Activo','Observaciones'];
      rows=all.map((r)=>[r['code'],r['name'],r['category'],r['active']==false?'No':'Sí',r['notes']]).toList();
      for(final r in all){final k='${r['category']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='assets'){
      h=['Código','Categoría','Descripción'];rows=all.map((r)=>[r['code'],r['category'],r['description']]).toList();
      for(final r in all){final k='${r['category']}';metrics[k]=(metrics[k]??0)+1;}
    }
    return OpsReport(title:types[type]!,headers:h,rows:rows,metrics:metrics,from:from,to:to);
  }

  /// Informe de situación para una fecha: registra hechos, pendientes y límites de la información.
  /// La falta de marcación NO significa ausencia; las asignaciones no acreditan tareas realizadas.
  static OpsReport dailyClose(Map<String,List<Map<String,dynamic>>> db,String day){
    final active=(db['operators']??[]).where((r)=>r['active']!=false).toList();
    final operators={for(final op in db['operators']??[])op['id']:'${op['name']??'Sin nombre'}'};
    final assets={for(final a in db['assets']??[])a['id']:'${a['code']??'Equipo sin código'}'};
    List<Map<String,dynamic>> rowsFor(String entity)=>
      (db[entity]??[]).where((r)=>r['date']==day).toList();
    String op(Map<String,dynamic> r)=>operators[r['operatorId']]??'Operador no registrado';
    String asset(Map<String,dynamic> r)=>assets[r['assetId']]??'Equipo no registrado';
    final attendance=rowsFor('attendance');
    final daysOff=rowsFor('daysOff');
    final schedules=rowsFor('schedules');
    final meals=rowsFor('meals');
    final tickets=rowsFor('tickets');
    final tomorrow=formatDay(DateTime.parse(day).add(const Duration(days:1)));
    final nextSchedules=(db['schedules']??[]).where((r)=>r['date']==tomorrow).toList();
    final countBy=<String,int>{};
    for(final a in attendance){final s='${a['status']}';countBy[s]=(countBy[s]??0)+1;}
    int count(String key)=>countBy[key]??0;
    final marked=attendance.map((r)=>r['operatorId']).toSet();
    final unmarked=active.where((o)=>!marked.contains(o['id'])).toList();
    final start=DateTime.parse(day);
    final end=start.add(const Duration(days:1));
    final now=DateTime.now();
    final cutoff=end.isAfter(now)?now:end;
    final faults=<Map<String,dynamic>>[];
    double hours=0;
    int stillOpen=0;
    for(final r in db['faults']??<Map<String,dynamic>>[]){
      final from=DateTime.tryParse('${r['start']??''}');
      final until=DateTime.tryParse('${r['end']??''}');
      if(from==null||!from.isBefore(cutoff)||!(until==null||until.isAfter(start)))continue;
      faults.add(r);
      final overlapStart=from.isAfter(start)?from:start;
      final overlapEnd=until!=null&&until.isBefore(cutoff)?until:cutoff;
      if(overlapEnd.isAfter(overlapStart))hours+=overlapEnd.difference(overlapStart).inMinutes/60;
      if(until==null||until.isAfter(cutoff))stillOpen++;
    }
    final impactedAssets=faults.where((r)=>r['end']==null||r['end']==''||DateTime.tryParse('${r['end']}')?.isAfter(cutoff)==true)
        .map((r)=>r['assetId']).toSet();
    final assetTotal=(db['assets']??[]).length;
    final warnings=<String>[];
    if(unmarked.isNotEmpty)warnings.add('Hay ${unmarked.length} operador(es) activo(s) sin marcación; verificar, no contar automáticamente como ausentes.');
    if(attendance.isEmpty)warnings.add('No hay marcaciones de asistencia registradas para este día.');
    if(schedules.isEmpty)warnings.add('No hay tareas ni horarios registrados para este día.');
    if(stillOpen>0)warnings.add('Hay $stillOpen avería(s) de equipos abiertas al corte.');
    if(nextSchedules.isEmpty)warnings.add('No hay programación registrada para el día siguiente.');
    final table=<List<Object?>>[];
    void line(String section,Object? name,Object? description,Object? state,[Object? notes=''])=>
      table.add([section,name??'',description??'',state??'',notes??'']);
    line('RESUMEN','Dotación actual','Operadores activos',active.length,'No equivale a dotación histórica del día.');
    for(final cat in categories){line('DOTACIÓN',cat,'Operadores activos',active.where((r)=>r['category']==cat).length);}
    line('ASISTENCIA','Presentes','Marcaciones de presencia',count('PRESENTE'));
    line('ASISTENCIA','Tardanzas','Marcaciones de tardanza',count('TARDANZA'));
    line('ASISTENCIA','Ausencias justificadas','Marcaciones de ausencia justificada',count('AUSENTE_JUST'));
    line('ASISTENCIA','Ausencias injustificadas','Marcaciones de ausencia injustificada',count('AUSENTE_INJUST'));
    line('ASISTENCIA','Libres marcados','Marcaciones de libre',count('LIBRE'));
    line('ASISTENCIA','Sin marcar','Operadores activos sin marcación',unmarked.length,'No equivale a ausencia.');
    line('PERSONAL','Descansos/permisos','Asignaciones de días libres',daysOff.length);
    line('OPERACIÓN','Tareas programadas del día','No acredita tareas ejecutadas',schedules.length);
    line('OPERACIÓN','Programación para mañana',prettyDate(tomorrow),nextSchedules.length);
    line('COMIDAS','Cenas solicitadas','Solicitudes, no entregas',meals.where((r)=>r['type']=='CENA').length);
    line('COMIDAS','Almuerzos solicitados','Solicitudes, no entregas',meals.where((r)=>r['type']=='ALMUERZO').length);
    line('INFRACCIONES','Tickets emitidos en el día','Cualquier estado',tickets.length);
    line('EQUIPOS','Equipos registrados','Maestro actual de equipos',assetTotal);
    line('EQUIPOS','Con avería abierta al corte','Sin validar disponibilidad física',impactedAssets.length);
    line('AVERÍAS','Incidencias que afectaron al día','Intervalos coincidentes con el día',faults.length);
    line('AVERÍAS','Horas fuera de servicio','Suma de intervalos dentro del día',hours.toStringAsFixed(2));
    for(final r in attendance){line('DETALLE ASISTENCIA',op(r),attendanceStates[r['status']]??r['status'],
      '${r['start']??''} – ${r['end']??''}',r['notes']);}
    for(final r in unmarked){line('PENDIENTE DE MARCACIÓN',r['name'],'Sin registro de asistencia','PENDIENTE','Revisar antes de cerrar.');}
    for(final r in daysOff){line('DETALLE LIBRES',op(r),r['type'],'Asignado',r['notes']);}
    for(final r in schedules){line('DETALLE TAREAS',op(r),r['task'],'${r['start']??''} – ${r['end']??''}',
      '${r['place']??''} · ${r['assetId']==null||r['assetId']==''?'Sin equipo':asset(r)}');}
    for(final r in meals){line('DETALLE COMIDAS',op(r),r['type'],'Solicitada',r['notes']);}
    for(final r in tickets){line('DETALLE INFRACCIONES',op(r),ticketReasons[r['reason']]??r['reason'],r['level'],
      '${r['status']??''} · ${r['description']??''}');}
    for(final r in faults){
      final begin=DateTime.tryParse('${r['start']??''}');
      final finish=DateTime.tryParse('${r['end']??''}');
      final clipStart=begin!=null&&begin.isAfter(start)?begin:start;
      final clipEnd=finish!=null&&finish.isBefore(cutoff)?finish:cutoff;
      final h=clipEnd.isAfter(clipStart)?clipEnd.difference(clipStart).inMinutes/60:0.0;
      line('DETALLE AVERÍAS',asset(r),r['description'],'${h.toStringAsFixed(2)} h',
        finish==null||finish.isAfter(cutoff)?'Abierta al corte':'Cerrada · ${r['notes']??''}');
    }
    for(final r in nextSchedules){line('PRÓXIMO TURNO',op(r),r['task'],'${r['start']??''} – ${r['end']??''}',r['place']);}
    if(warnings.isEmpty)line('VALIDACIÓN','Pendientes de captura','No detectados según campos disponibles','VERIFICAR','No implica certificación de ejecución.');
    for(final w in warnings){line('VALIDACIÓN','Requiere revisión',w,'PENDIENTE');}
    return OpsReport(
      title:'Cierre operacional diario · ${prettyDate(day)}',from:day,to:day,
      headers:const ['Bloque','Operador / indicador','Detalle','Valor / estado','Observaciones'],
      rows:table,
      metrics:{
        'Dotación actual':active.length.toDouble(),
        'Presentes':count('PRESENTE').toDouble(),
        'Tardanzas':count('TARDANZA').toDouble(),
        'Sin marcar':unmarked.length.toDouble(),
        'Tareas programadas':schedules.length.toDouble(),
        'Infracciones':tickets.length.toDouble(),
        'Equipos con avería':impactedAssets.length.toDouble(),
        'Horas fuera (h)':double.parse(hours.toStringAsFixed(2)),
        'Cenas':meals.where((r)=>r['type']=='CENA').length.toDouble(),
        'Almuerzos':meals.where((r)=>r['type']=='ALMUERZO').length.toDouble(),
      },
    );
  }

  static String keyOr(Map r,Map assets)=>assets[r['assetId']]??'No registrado';
}
