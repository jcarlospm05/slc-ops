import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'catalog.dart';
import 'reporting.dart';

/// Archivo multipágina A4 preparado para compartir o imprimir sin Internet.
class PdfExport {
  static Future<Uint8List> build(OpsReport report) async {
    final pdf=pw.Document(title:report.title,author:'WorkFlow - Operaciones',compress:true);
    final isClose=report.title.startsWith('Cierre operacional diario');
    final navy=PdfColor.fromHex('#142F50');
    final blue=PdfColor.fromHex('#287C9C');
    final pale=PdfColor.fromHex('#EDF4F8');
    final columns=report.headers;
    final rows=report.rows;
    // Las tablas se componen automáticamente entre páginas; no se omiten filas.
    pdf.addPage(pw.MultiPage(
      pageFormat:PdfPageFormat.a4.landscape,
      margin:const pw.EdgeInsets.fromLTRB(30,30,30,34),
      header:(ctx)=>pw.Container(
        padding:const pw.EdgeInsets.only(bottom:12),
        decoration:pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(color:blue,width:1.7))),
        child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
          pw.Text('WorkFlow',style:pw.TextStyle(fontSize:19,fontWeight:pw.FontWeight.bold,color:navy)),
          pw.Text('Departamento de Operaciones',style:pw.TextStyle(color:navy,fontSize:10)),
        ]),
      ),
      footer:(ctx)=>pw.Container(
        padding:const pw.EdgeInsets.only(top:7),
        decoration:pw.BoxDecoration(border:pw.Border(top:pw.BorderSide(color:PdfColors.grey400,width:.5))),
        child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
          pw.Text('Fuente: registros locales de WorkFlow. Verificar datos faltantes.',style:const pw.TextStyle(fontSize:8)),
          pw.Text('Pág. ${ctx.pageNumber} de ${ctx.pagesCount}',style:const pw.TextStyle(fontSize:8)),
        ]),
      ),
      build:(ctx)=>[
        pw.SizedBox(height:13),
        pw.Text(report.title,style:pw.TextStyle(fontSize:17,fontWeight:pw.FontWeight.bold,color:navy)),
        pw.SizedBox(height:5),
        pw.Text(isClose?'Fecha de cierre: ${prettyDate(report.from)}':'Desde ${prettyDate(report.from)} hasta ${prettyDate(report.to)}',
          style:const pw.TextStyle(fontSize:10)),
        pw.SizedBox(height:14),
        pw.Wrap(spacing:7,runSpacing:7,children:report.metrics.entries.map((e)=>pw.Container(
          width:137,padding:const pw.EdgeInsets.all(10),
          decoration:pw.BoxDecoration(color:pale,borderRadius:pw.BorderRadius.circular(7)),
          child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
            pw.Text(e.key,style:pw.TextStyle(fontSize:8,color:navy)),
            pw.SizedBox(height:4),
            pw.Text(e.value.toStringAsFixed(e.value==e.value.roundToDouble()?0:2),style:pw.TextStyle(fontSize:16,fontWeight:pw.FontWeight.bold,color:navy)),
          ]),
        )).toList()),
        pw.SizedBox(height:16),
        pw.Text(isClose?'Estado y detalle de la jornada':'Detalle de registros',style:pw.TextStyle(color:navy,fontSize:12,fontWeight:pw.FontWeight.bold)),
        pw.SizedBox(height:8),
        pw.TableHelper.fromTextArray(
          headers:columns,
          data:rows.map((row)=>row.map((x)=>'${x??''}').toList()).toList(),
          headerDecoration:pw.BoxDecoration(color:navy),
          headerStyle:pw.TextStyle(color:PdfColors.white,fontSize:8,fontWeight:pw.FontWeight.bold),
          cellStyle:const pw.TextStyle(fontSize:7.3),
          cellPadding:const pw.EdgeInsets.symmetric(horizontal:6,vertical:6),
          cellAlignment:pw.Alignment.centerLeft,
          oddRowDecoration:pw.BoxDecoration(color:pale),
          border:pw.TableBorder(horizontalInside:pw.BorderSide(width:.2,color:PdfColors.grey350)),
        ),
        if(rows.isEmpty)pw.Padding(padding:const pw.EdgeInsets.all(12),child:pw.Text('No hay registros en el período seleccionado.')),
        if(isClose)...[
          pw.SizedBox(height:24),
          pw.Text('Observaciones y validación',style:pw.TextStyle(fontWeight:pw.FontWeight.bold,fontSize:11,color:navy)),
          pw.SizedBox(height:7),
          pw.Text('Este informe refleja registros capturados, no certifica ejecución física de tareas, entrega de comidas ni asistencia no marcada.',style:const pw.TextStyle(fontSize:9)),
          pw.SizedBox(height:22),
          pw.Row(children:[
            pw.Expanded(child:pw.Text('____________________________\nPreparado por Operaciones',style:const pw.TextStyle(fontSize:9))),
            pw.Expanded(child:pw.Text('____________________________\nRevisado / aprobado por',style:const pw.TextStyle(fontSize:9))),
          ]),
        ],
      ],
    ));
    return pdf.save();
  }
}
