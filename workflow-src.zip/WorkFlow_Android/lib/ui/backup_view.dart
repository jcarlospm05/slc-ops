import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../core/backup_service.dart';
import '../core/controller.dart';
import '../core/office_export.dart';
import 'common.dart';

class BackupView extends StatelessWidget{
  const BackupView({super.key,required this.controller});
  final OpsController controller;
  Future<void> backup(BuildContext context)async{
    try{
      final f=await OfficeExport.backup(controller.records);
      if(context.mounted)message(context,'Respaldo generado: ${f.path}');
      await SharePlus.instance.share(ShareParams(files:[XFile(f.path)],text:'Respaldo completo WorkFlow'));
    }catch(e){if(context.mounted)message(context,'Error creando respaldo: $e',error:true);}
  }
  Future<void> restore(BuildContext context)async {
    try {
      final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
      final bytes=picked?.files.single.bytes;
      if(bytes==null)return;
      final data=BackupService.parse(bytes);
      final n=data.values.fold<int>(0,(p,x)=>p+x.length);
      if(!context.mounted)return;
      if(!await confirm(context,'¿Reemplazar todos los registros de SQLite por los $n registros del archivo JSON? Primero realiza un respaldo.'))return;
      await controller.importAll(data);
      if(context.mounted)message(context,'Restauración completa y validada');
    }catch(e){if(context.mounted)message(context,'No se restauró: $e',error:true);}
  }
  @override Widget build(BuildContext context)=>ListView(children:[
    header('Respaldo y mantenimiento','La información se guarda en SQLite del almacenamiento privado del teléfono.'),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
      const Icon(Icons.security,size:48,color:Colors.indigo),const SizedBox(height:12),
      const Text('La base no se sincroniza automáticamente con Google Drive.',style:TextStyle(fontWeight:FontWeight.bold)),
      const Text('Puedes enviar el respaldo JSON a Drive usando el menú Compartir de Android.'),
      const SizedBox(height:16),
      SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>backup(context),icon:const Icon(Icons.backup_outlined),label:const Text('Crear respaldo JSON y compartir'))),
      const SizedBox(height:8),
      SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:()=>restore(context),icon:const Icon(Icons.restore),label:const Text('Restaurar JSON de WorkFlow web / móvil'))),
    ]))),
    Card(child:ListTile(title:const Text('Trazabilidad'),subtitle:const Text('SQLite mantiene un registro de creación, edición y eliminación. Sin autenticación ni cifrado nativo.'),trailing:FutureBuilder<int>(future:controller.database.auditCount(),builder:(ctx,s)=>Text('${s.data??'…'} cambios')))),
    const Padding(padding:EdgeInsets.all(16),child:Text('Aviso: usa bloqueo de pantalla, respaldos externos y un dispositivo autorizado para datos del personal. Al desinstalar la app pueden eliminarse la base y los reportes privados. Para un entorno multiusuario se necesitarán usuarios, roles y sincronización posterior.',style:TextStyle(color:Colors.blueGrey))),
  ]);
}
