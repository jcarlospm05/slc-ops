import 'dart:io';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import '../core/reporting.dart';
import '../core/office_export.dart';
import 'common.dart';

class ReportsView extends StatefulWidget{
  const ReportsView({super.key,required this.controller});
  final OpsController controller;
  @override State<ReportsView> createState()=>_ReportsViewState();
}
class _ReportsViewState extends State<ReportsView>{
  String kind='cierre_diario';
  String from=formatDay(DateTime.now());
  String to=formatDay(DateTime.now());
  OpsReport? current;
  bool exporting=false;
  bool get isDaily=>kind=='cierre_diario';
  void generate(){
    if(from.compareTo(to)>0){message(context,'La fecha inicial debe ser anterior a la final',error:true);return;}
    setState(()=>current=ReportEngine.make(widget.controller.records,kind,from,to));
  }
  Future<void> export(String type)async{
    final report=current;
    if(report==null)return;
    setState(()=>exporting=true);
    try{
      final bytes=switch(type){
        'xlsx'=>OfficeExport.xlsx(report),
        'csv'=>OfficeExport.csv(report),
        'pdf'=>await OfficeExport.pdf(report),
        _=>await OfficeExport.docx(report),
      };
      final file=await OfficeExport.save('WorkFlow_${kind}_${report.from}_${report.to}.$type',bytes);
      if(!mounted)return;
      await _shareFile(file);
    }catch(e){if(mounted)message(context,'Exportación falló: $e',error:true);}
    finally{if(mounted)setState(()=>exporting=false);}
  }
  Future<void> printReport()async{
    final report=current;
    if(report==null)return;
    setState(()=>exporting=true);
    try{
      final pdf=await OfficeExport.pdf(report);
      await Printing.layoutPdf(onLayout:(_)=>pdf,name:'WorkFlow - ${report.title}');
    }catch(e){if(mounted)message(context,'No se pudo abrir impresión: $e',error:true);}
    finally{if(mounted)setState(()=>exporting=false);}
  }
  Future<void> _shareFile(File file)async{
    if(!mounted)return;
    message(context,'Reporte guardado en ${file.path}');
    await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'Reporte WorkFlow'));
  }
  @override Widget build(BuildContext context){
    final report=current;
    final daily=report!=null&&isDaily;
    final issues=daily?report.rows.where((r)=>r.isNotEmpty&&r.first=='VALIDACIÓN'&&r.length>3&&r[3]=='PENDIENTE').length:0;
    final sections=daily?report.rows.map((r)=>'${r.first}').toSet().toList():<String>[];
    return Column(children:[
      header('Centro de reportes','Informes imprimibles y exportables en PDF, Excel, Word y CSV.'),
      Card(
        margin:const EdgeInsets.only(bottom:12),
        child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          DropdownButtonFormField<String>(
            key:ValueKey('report_type_$kind'),
            initialValue:kind,isExpanded:true,
            decoration:const InputDecoration(labelText:'Seleccionar reporte',border:OutlineInputBorder()),
            items:ReportEngine.types.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value,overflow:TextOverflow.ellipsis))).toList(),
            onChanged:(v)=>setState((){
              kind=v??kind;
              current=null;
              if(kind=='cierre_diario'){from=to;}
            }),
          ),
          const SizedBox(height:12),
          Wrap(spacing:8,runSpacing:8,children:[
            if(isDaily)OutlinedButton.icon(
              icon:const Icon(Icons.today),
              label:Text('Día: ${prettyDate(to)}'),
              onPressed:()async{
                final d=await chooseDate(context,to);
                if(d!=null)setState((){from=d;to=d;current=null;});
              },
            ) else ...[
              OutlinedButton(onPressed:()async{final d=await chooseDate(context,from);if(d!=null)setState((){from=d;current=null;});},child:Text('Desde: ${prettyDate(from)}')),
              OutlinedButton(onPressed:()async{final d=await chooseDate(context,to);if(d!=null)setState((){to=d;current=null;});},child:Text('Hasta: ${prettyDate(to)}')),
            ],
            FilledButton.icon(onPressed:generate,icon:const Icon(Icons.analytics_outlined),label:const Text('Generar reporte')),
          ]),
        ]))),
      if(report!=null)Padding(padding:const EdgeInsets.only(bottom:8),child:Wrap(spacing:7,runSpacing:8,children:[
        FilledButton.tonalIcon(onPressed:exporting?null:printReport,icon:const Icon(Icons.print),label:const Text('Imprimir')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('pdf'),icon:const Icon(Icons.picture_as_pdf),label:const Text('PDF')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('xlsx'),icon:const Icon(Icons.table_chart),label:const Text('Excel')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('docx'),icon:const Icon(Icons.description),label:const Text('Word')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('csv'),icon:const Icon(Icons.file_download),label:const Text('CSV')),
      ])),
      Expanded(child:report==null
        ?emptyState('Selecciona el reporte y pulsa Generar. El cierre resume toda la jornada y sus pendientes.')
        :ListView(children:[
          if(daily)Card(color:issues>0?const Color(0xFFFFF5E6):const Color(0xFFE8F6F2),child:Padding(
            padding:const EdgeInsets.all(16),
            child:Row(children:[
              Icon(issues>0?Icons.fact_check_outlined:Icons.verified_outlined,color:const Color(0xFF116A78),size:30),
              const SizedBox(width:12),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(issues>0?'Cierre pendiente de verificación':'Sin pendientes detectados',style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16)),
                const SizedBox(height:4),
                Text(issues>0?'$issues observaciones requieren revisión.':'Verifica los registros antes de entregar el informe.',style:const TextStyle(height:1.3)),
              ])),
            ]),
          )),
          Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(report.title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
            const SizedBox(height:13),
            Wrap(spacing:8,runSpacing:8,children:report.metrics.entries.map((e)=>Container(
              width:145,padding:const EdgeInsets.all(12),
              decoration:BoxDecoration(color:const Color(0xFFF1F6FB),borderRadius:BorderRadius.circular(12)),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(e.value.toStringAsFixed(e.value==e.value.roundToDouble()?0:2),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:Color(0xFF173E5C))),
                const SizedBox(height:3),
                Text(e.key,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:12)),
              ]),
            )).toList()),
          ]))),
          if(daily)...[
            for(final section in sections)Card(child:ExpansionTile(
              key:PageStorageKey(section),
              initiallyExpanded:section=='VALIDACIÓN',
              title:Text(section,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:14)),
              subtitle:Text('${report.rows.where((r)=>r.first==section).length} registros'),
              children:report.rows.where((r)=>r.first==section).map((row)=>ListTile(
                dense:true,
                title:Text('${row[1]}',style:const TextStyle(fontWeight:FontWeight.w600)),
                subtitle:Text('${row[2]}${row[4]==null||'${row[4]}'.isEmpty?'':' · ${row[4]}'}'),
                trailing:ConstrainedBox(constraints:const BoxConstraints(maxWidth:88),child:Text('${row[3]}',textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12))),
              )).toList(),
            )),
          ]else Card(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(
            columns:report.headers.map((h)=>DataColumn(label:Text(h))).toList(),
            rows:report.rows.take(150).map((r)=>DataRow(cells:r.map((v)=>DataCell(Text('${v??''}'))).toList())).toList(),
          ))),
          if(!daily&&report.rows.length>150)const Padding(padding:EdgeInsets.all(12),child:Text('Vista previa limitada a 150 filas. La exportación incluye todas las filas (Word: primeras 400).')),
        ])),
    ]);
  }
}
