import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/controller.dart';
import 'ui/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const WorkFlowApp());
}

class WorkFlowApp extends StatefulWidget {
  const WorkFlowApp({super.key});
  @override State<WorkFlowApp> createState()=>_WorkFlowAppState();
}
class _WorkFlowAppState extends State<WorkFlowApp> {
  final OpsController controller=OpsController();
  @override void initState(){super.initState();controller.initialize();}
  @override void dispose(){controller.database.close();controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'WorkFlow',debugShowCheckedModeBanner:false,
    locale:const Locale('es'),
    supportedLocales:const [Locale('es'),Locale('en')],
    localizationsDelegates:const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF1559A9)),
      scaffoldBackgroundColor:const Color(0xFFF5F7FC),cardTheme:const CardThemeData(margin:EdgeInsets.symmetric(vertical:6))),
    home:AppShell(controller:controller),
  );
}
