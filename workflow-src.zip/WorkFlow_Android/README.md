# WorkFlow Android · Flutter/Dart · SQLite local

Proyecto derivado de ControlOPS Web v2, preparado para evolucionar en módulos con archivos separados en Google Drive. **Estado: WorkFlow v0.2, con cierre diario y reportes imprimibles; requiere compilación y pruebas reales en Android.**

## Plataforma

- Flutter/Dart y Material 3 (sin conexión en ejecución).
- SQLite dentro de la carpeta privada de la aplicación en Android: `controlops.sqlite`. No usa Internet ni Google Drive para consultar los registros.
- Tabla de registros con índices por operador/fecha y registro de auditoría `audit_log` para altas, ediciones, borrados y restauración.
- Exportación a XLSX con gráfico OOXML nativo, DOCX con gráfico PNG, CSV, JPG de tickets y respaldo/restauración de JSON.
- Android comparte reportes y respaldos mediante el menú de compartir del teléfono: se puede elegir Google Drive en esa pantalla si está disponible.

## Compilación

Requisitos para compilar: **PC con Flutter y Android SDK**, Java 17, Android Studio o SDK de línea de comandos. Se requiere Internet durante la primera instalación de dependencias; la app ya instalada funciona sin Internet.

1. Descomprimir el ZIP en una carpeta, o descargar toda la carpeta desde Drive.
2. En terminal, dentro de la carpeta del proyecto:

   ```bash
   flutter create --platforms=android --project-name controlops_android .
   flutter pub get
   flutter analyze
   flutter test
   flutter run
   flutter build apk --release
   ```

   `flutter create` completa los archivos de arranque de Android que dependen de la versión de Flutter, incluido el wrapper Gradle. **Revisar después que no se agregue permiso INTERNET**. Durante desarrollo la firma de release será de depuración; no es apropiada para distribución final.

3. APK esperado una vez compilado: `build/app/outputs/flutter-apk/app-release.apk`.

## Archivos por módulo

- `lib/core/catalog.dart`: categorías, tipos y campos de formularios.
- `lib/core/database.dart`: SQLite y bitácora; cambios de esquema requerirán migraciones.
- `lib/core/controller.dart`: estado y operaciones.
- `lib/core/security.dart`: límites de datos y seguridad de exportación.
- `lib/core/backup_service.dart`: restauración desde el JSON completo de ControlOPS Web 1/2 o JSON móvil.
- `lib/core/reporting.dart`: consolidación de KPI.
- `lib/core/office_export.dart`: Excel, Word, CSV, respaldo en archivos de app.
- `lib/core/ticket_image.dart`: comprobante JPG de infracción.
- `lib/ui/*.dart`: cada pantalla.
- `test/security_test.dart`: pruebas unitarias.

## Migrar datos desde ControlOPS Web 2

En el PC, exportar un **respaldo JSON completo** desde ControlOPS Web. En la app Android, ir a `Respaldos > Restaurar JSON`, seleccionar ese respaldo y confirmar. Esto **reemplaza** la base del teléfono, no fusiona. No admite la carpeta de 11 JSON individuales directamente; primero hacer backup completo desde la aplicación Web.

## Google Drive y actualizaciones

La carpeta de Drive guarda **solo el código fuente**, cada archivo Dart separado. No implica sincronización de datos laborales ni actualización automática del APK. Los archivos `.dart` son archivos de código, **no** documentos nativos de Google Docs; su modificación se gestiona mediante actualización/reemplazo de cada archivo de Drive o descarga/edición en un editor de código. Para instalar cambios hay que compilar y volver a instalar una versión nueva del APK.

## Privacidad y limitaciones

- La base de datos SQLite **no está cifrada**; Android aísla los datos entre aplicaciones, pero no elimina riesgos de un dispositivo comprometido.
- No hay autenticación con roles, control de firmas, sincronización multiusuario o conservación inalterable de sanciones.
- Se guardan auditorías de cambios en el dispositivo, pero un usuario con control total del teléfono puede manipular su almacenamiento.
- Antes de uso laboral real, validar políticas de la empresa, derecho a rectificación, los criterios de productividad y retención de datos personales.
- Los reportes Word limitan la tabla a **400 filas** en esta primera versión; Excel/CSV exportan todas las disponibles.
- Los archivos y tickets se guardan en almacenamiento privado y se exportan mediante **Compartir**. El JPG se genera en el directorio de reportes y se comparte desde la lista mediante el menú de Android.
- No se ha ejecutado `flutter analyze`, `flutter test` ni generado el APK en este entorno porque el SDK de Flutter no está instalado. El archivo de pruebas es para ejecutar localmente.

## Identidad WorkFlow (v0.2)

- Marca visible: **WorkFlow**; iconografía vectorial en `branding/workflow_icon.svg`.
- Recursos Android: iconos de lanzamiento en `android/app/src/main/res/`.
- ID Android para esta nueva versión: `com.workflow.operaciones`, independiente del APK previo.
- Si ya tienes datos en la app anterior, exporta primero su respaldo JSON y restáuralo en WorkFlow. No borres la anterior hasta verificar la migración.
- El archivo de base de datos sigue llamándose `controlops.sqlite` por compatibilidad del formato interno.
