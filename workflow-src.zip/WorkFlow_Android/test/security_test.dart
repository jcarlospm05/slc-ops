import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:controlops_android/core/backup_service.dart';
import 'package:controlops_android/core/catalog.dart';
import 'package:controlops_android/core/security.dart';
import 'package:controlops_android/core/reporting.dart';
import 'package:controlops_android/core/pdf_export.dart';

void main(){
  test('CSV no ejecuta formulas de Excel',(){
    expect(csvCell('=HYPERLINK("https://attacker.test")'),startsWith('"\'=HYPERLINK'));
    expect(csvCell(' @SUM(1)'),startsWith('"\' @SUM'));
  });
  test('XML escapa contenido de personal',(){
    expect(xmlEscape('<script>&'),equals('&lt;script&gt;&amp;'));
  });
  test('Rechaza categorias arbitrarias',(){
    expect(()=>validatedRecord('operators',{'id':'1','category':'Root'}),throwsA(isA<DataValidationException>()));
  });
  test('Rechaza rango de averia invertido',(){
    expect(()=>validatedRecord('faults',{'id':'1','start':'2026-11-04T12:00','end':'2026-11-03T10:00'}),throwsA(isA<DataValidationException>()));
  });
  test('Solo se permite almuerzo sabado, domingo o feriado',(){
    expect(isLunchAllowed('2026-11-02',const []),isFalse);
    expect(isLunchAllowed('2026-11-07',const []),isTrue);
    expect(isLunchAllowed('2026-11-02',const ['2026-11-02']),isTrue);
  });
  test('Respaldo no reemplaza arrays con valores invalidos',(){
    final body={for(final x in entities)x:<Object>[]};
    body['tickets']=[{'id':'x','reason':'INVALID','level':'Advertencia final','status':'ABIERTO'}];
    final encoded=Uint8List.fromList(utf8.encode(jsonEncode(body)));
    expect(()=>BackupService.parse(encoded),throwsA(isA<DataValidationException>()));
  });
  test('Cierre diario distingue sin marcar de inasistencia y calcula tiempo fuera',(){
    final db=<String,List<Map<String,dynamic>>>{for(final e in entities)e:[]};
    db['operators']=[
      {'id':'op1','name':'Ana','category':'Mula','active':true},
      {'id':'op2','name':'Luis','category':'Grúa','active':true}
    ];
    db['assets']=[{'id':'m1','code':'MU-01','category':'Mula'}];
    db['attendance']=[{'id':'a1','operatorId':'op1','date':'2026-11-01','status':'PRESENTE'}];
    db['faults']=[{'id':'f1','assetId':'m1','start':'2026-10-31T23:00','end':'2026-11-01T03:00','description':'Sin arranque'}];
    db['schedules']=[{'id':'s1','date':'2026-11-01','operatorId':'op1','task':'Mover contenedores'}];
    final r=ReportEngine.make(db,'cierre_diario','2026-11-01','2026-11-01');
    expect(r.metrics['Dotación actual'],2);
    expect(r.metrics['Presentes'],1);
    expect(r.metrics['Sin marcar'],1);
    expect(r.metrics['Horas fuera (h)'],3);
    expect(r.metrics.containsKey('Ausencias injustificadas'),false);
    expect(r.rows.where((row)=>row[0]=='PENDIENTE DE MARCACIÓN').length,1);
    expect(r.rows.where((row)=>row[0]=='VALIDACIÓN' && row[3]=='PENDIENTE').isNotEmpty,isTrue);
  });
  test('PDF del cierre produce un documento con firma PDF',()async{
    final db=<String,List<Map<String,dynamic>>>{for(final e in entities)e:[]};
    final r=ReportEngine.dailyClose(db,'2026-11-01');
    final file=await PdfExport.build(r);
    expect(file.length,greaterThan(1500));
    expect(utf8.decode(file.take(4).toList()),'%PDF');
  });
  test('Respaldo acepta la estructura del sitio version 2',(){
    final body={for(final x in entities)x:[]};
    final result=BackupService.parse(Uint8List.fromList(utf8.encode(jsonEncode(body))));
    expect(result.keys,containsAll(entities));
  });
}
