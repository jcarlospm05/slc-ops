import 'package:flutter/material.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import '../core/security.dart';
import 'common.dart';

class MealsView extends StatefulWidget{
  const MealsView({super.key,required this.controller});
  final OpsController controller;
  @override State<MealsView> createState()=>_MealsViewState();
}
class _MealsViewState extends State<MealsView>{
  String date=formatDay(DateTime.now()),type='CENA';
  Set<String> selected={};
  final notes=TextEditingController();
  @override void initState(){super.initState();_reload();}
  void _reload(){selected=widget.controller.items('meals').where((r)=>r['date']==date&&r['type']==type).map((r)=>'${r['operatorId']}').toSet();
    notes.text='${widget.controller.items('meals').where((r)=>r['date']==date&&r['type']==type).firstOrNull?['notes']??''}';
  }
  @override void dispose(){notes.dispose();super.dispose();}
  Future<void> save()async{
    try{await widget.controller.replaceMeals(date,type,selected.toList(),notes.text.trim());if(mounted)message(context,'Solicitud de $type guardada: ${selected.length} operadores');}
    catch(e){if(mounted)message(context,'Error: $e',error:true);}
  }
  Widget _emptyOperatorsCard() {
    return Card(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.badge_outlined,size:42,color:Colors.indigo.shade300),
              const SizedBox(height:12),
              const Text('No hay operadores activos',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
              const SizedBox(height:6),
              const Text('Primero registra operadores en el módulo Operadores para generar solicitudes de comidas.',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey,height:1.3)),
            ],
          ),
        ),
      ),
    );
  }
  @override Widget build(BuildContext context){
    final valid=type=='CENA'||isLunchAllowed(date,widget.controller.items('holidays').map((h)=>'${h['date']}'));
    final ops=widget.controller.activeOperators;
    return Column(children:[
      header('Solicitud de comidas','Cena diaria y almuerzo los sábados, domingos o feriados.'),
      Wrap(spacing:10,runSpacing:10,crossAxisAlignment:WrapCrossAlignment.center,children:[
        OutlinedButton.icon(onPressed:()async{final d=await chooseDate(context,date);if(d!=null)setState((){date=d;_reload();});},icon:const Icon(Icons.event),label:Text(prettyDate(date))),
        SizedBox(width:170,child:DropdownButton<String>(
          value:type,
          isExpanded:true,
          items:const [
            DropdownMenuItem<String>(value:'CENA',child:Text('Cena')),
            DropdownMenuItem<String>(value:'ALMUERZO',child:Text('Almuerzo')),
          ],
          onChanged:(String? chosen){
            if(chosen==null)return;
            setState((){type=chosen;_reload();});
          },
        )),
        FilledButton.tonal(onPressed:ops.isEmpty?null:()=>setState(()=>selected=ops.map((o)=>'${o['id']}').toSet()),child:const Text('Todos')),
        TextButton(onPressed:selected.isEmpty?null:()=>setState(()=>selected.clear()),child:const Text('Limpiar')),
      ]),
      const SizedBox(height:8),
      if(!valid)const Card(child:ListTile(leading:Icon(Icons.warning_amber),title:Text('Almuerzo permitido solo sábado, domingo o feriado registrado.'))),
      TextField(controller:notes,maxLength:220,minLines:1,maxLines:3,decoration:const InputDecoration(labelText:'Observaciones de la solicitud')),
      const SizedBox(height:6),
      Align(alignment:Alignment.centerLeft,child:Text('${selected.length} operadores seleccionados',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),
      const SizedBox(height:6),
      Expanded(
        child:ops.isEmpty
          ?_emptyOperatorsCard()
          :ListView.separated(
              padding:const EdgeInsets.only(bottom:12),
              itemCount:ops.length,
              separatorBuilder:(_,__)=>const SizedBox(height:2),
              itemBuilder:(context,index){
                final op=ops[index];
                return Card(child:CheckboxListTile(
                  contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),
                  value:selected.contains(op['id']),title:Text('${op['name']}'),subtitle:Text('${op['category']}'),
                  onChanged:(v)=>setState((){if(v==true){selected.add('${op['id']}');}else{selected.remove('${op['id']}');}}),
                ));
              },
            ),
      ),
      SafeArea(
        top:false,
        child:Padding(
          padding:const EdgeInsets.only(top:8),
          child:SizedBox(width:double.infinity,height:52,child:FilledButton.icon(onPressed:valid?save:null,icon:const Icon(Icons.save),label:const Text('Guardar solicitud'))),
        ),
      ),
    ]);
  }
}
