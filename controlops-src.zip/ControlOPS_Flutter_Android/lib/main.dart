import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/controller.dart';
import 'ui/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ControlOpsApp());
}

class ControlOpsApp extends StatefulWidget {
  const ControlOpsApp({super.key});
  @override State<ControlOpsApp> createState()=>_ControlOpsAppState();
}
class _ControlOpsAppState extends State<ControlOpsApp> {
  final OpsController controller=OpsController();
  @override void initState(){super.initState();controller.initialize();}
  @override void dispose(){controller.database.close();controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'ControlOPS',debugShowCheckedModeBanner:false,
    locale:const Locale('es'),
    supportedLocales:const [Locale('es'),Locale('en')],
    localizationsDelegates:const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF1D4ED8)),
      scaffoldBackgroundColor:const Color(0xFFF5F7FC),cardTheme:const CardThemeData(margin:EdgeInsets.symmetric(vertical:6))),
    home:AppShell(controller:controller),
  );
}
