import 'package:flutter/material.dart';
import '../core/catalog.dart';

Future<void> message(BuildContext context,String text,{bool error=false})async{
  if(!context.mounted)return;
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text),backgroundColor:error?Colors.red.shade800:null));
}
Future<bool> confirm(BuildContext context,String question)async{
  return await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
    title:const Text('Confirmar operación'),content:Text(question),actions:[
      TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),
      FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Confirmar')),
    ],))??false;
}
Future<String?> chooseDate(BuildContext context,String current)async{
  final initial=DateTime.tryParse(current)??DateTime.now();
  final result=await showDatePicker(context:context,initialDate:initial,
    firstDate:DateTime(2020),lastDate:DateTime(2100),locale:const Locale('es'));
  return result==null?null:formatDay(result);
}
Widget emptyState(String text)=>Padding(padding:const EdgeInsets.all(24),child:Center(child:Text(text,style:const TextStyle(color:Colors.blueGrey))));
Widget header(String title,String subtitle)=>Padding(padding:const EdgeInsets.symmetric(vertical:10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Text(title,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:4),
  Text(subtitle,style:const TextStyle(color:Colors.blueGrey)),
]));
Widget statCard(String title,Object value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[
  CircleAvatar(child:Icon(icon)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('$value',style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),Text(title,style:const TextStyle(fontSize:12)),
  ])),
])));
