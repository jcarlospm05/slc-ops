import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import '../core/reporting.dart';
import '../core/office_export.dart';
import 'common.dart';

class ReportsView extends StatefulWidget{
  const ReportsView({super.key,required this.controller});
  final OpsController controller;
  @override State<ReportsView> createState()=>_ReportsViewState();
}
class _ReportsViewState extends State<ReportsView>{
  String kind='asistencia_resumen';
  String from=formatDay(DateTime.now().subtract(const Duration(days:30)));
  String to=formatDay(DateTime.now());
  OpsReport? current;
  bool exporting=false;
  void generate(){
    if(from.compareTo(to)>0){message(context,'La fecha inicial debe ser anterior a la final',error:true);return;}
    setState(()=>current=ReportEngine.make(widget.controller.records,kind,from,to));
  }
  Future<void> export(String type)async{
    final report=current;
    if(report==null)return;
    setState(()=>exporting=true);
    try{
      final bytes=switch(type){
        'xlsx'=>OfficeExport.xlsx(report),
        'csv'=>OfficeExport.csv(report),
        _=>await OfficeExport.docx(report),
      };
      final file=await OfficeExport.save('ControlOPS_${kind}_${from}_$to.$type',bytes);
      if(!mounted)return;
      await _shareFile(file);
    }catch(e){if(mounted)message(context,'Exportación falló: $e',error:true);}
    finally{if(mounted)setState(()=>exporting=false);}
  }
  Future<void> _shareFile(File file)async{
    if(!mounted)return;
    message(context,'Reporte guardado en ${file.path}');
    await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'Reporte ControlOPS'));
  }
  @override Widget build(BuildContext context){
    final report=current;
    return Column(children:[
      header('Reportes operacionales','Excel y Word reales con indicadores y gráficos; también CSV.'),
      Wrap(spacing:8,runSpacing:8,children:[
        SizedBox(width:240,child:DropdownButtonFormField<String>(value:kind,isExpanded:true,decoration:const InputDecoration(labelText:'Reporte',border:OutlineInputBorder()),
          items:ReportEngine.types.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value,overflow:TextOverflow.ellipsis))).toList(),
          onChanged:(v)=>setState(()=>kind=v??kind))),
        OutlinedButton(onPressed:()async{final d=await chooseDate(context,from);if(d!=null)setState(()=>from=d);},child:Text('Desde: ${prettyDate(from)}')),
        OutlinedButton(onPressed:()async{final d=await chooseDate(context,to);if(d!=null)setState(()=>to=d);},child:Text('Hasta: ${prettyDate(to)}')),
        FilledButton.icon(onPressed:generate,icon:const Icon(Icons.analytics_outlined),label:const Text('Generar')),
      ]),const SizedBox(height:9),
      if(report!=null)Wrap(spacing:8,children:[
        OutlinedButton.icon(onPressed:exporting?null:()=>export('xlsx'),icon:const Icon(Icons.table_chart),label:const Text('Excel XLSX')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('docx'),icon:const Icon(Icons.description),label:const Text('Word DOCX')),
        OutlinedButton.icon(onPressed:exporting?null:()=>export('csv'),icon:const Icon(Icons.file_download),label:const Text('CSV')),
      ]),
      Expanded(child:report==null?emptyState('Selecciona un tipo y presiona Generar.'):ListView(children:[
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('${report.title} · ${report.rows.length} registros',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),const SizedBox(height:14),
          for(final m in report.metrics.entries.take(10))Padding(padding:const EdgeInsets.only(bottom:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Expanded(child:Text(m.key,overflow:TextOverflow.ellipsis)),Text(m.value.toStringAsFixed(1))]),
            LinearProgressIndicator(minHeight:10,borderRadius:BorderRadius.circular(8),value:report.metrics.values.fold<double>(1,(p,n)=>p>n?p:n)<=0?0:m.value/report.metrics.values.fold<double>(1,(p,n)=>p>n?p:n)),
          ])),
          if(report.metrics.isEmpty)const Text('No hay indicadores para este período.'),
        ]))),
        Card(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(
          columns:report.headers.map((h)=>DataColumn(label:Text(h))).toList(),
          rows:report.rows.take(150).map((r)=>DataRow(cells:r.map((v)=>DataCell(Text('${v??''}'))).toList())).toList(),
        ))),
        if(report.rows.length>150)const Padding(padding:EdgeInsets.all(12),child:Text('Vista previa limitada a 150 filas. La exportación incluye todas las filas (Word: primeras 400).')),
      ])),
    ]);
  }
}
