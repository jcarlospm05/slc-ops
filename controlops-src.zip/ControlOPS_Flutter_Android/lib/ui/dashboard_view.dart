import 'package:flutter/material.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import 'common.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({super.key,required this.controller});
  final OpsController controller;
  @override Widget build(BuildContext context){
    final today=formatDay(DateTime.now());
    final marks=controller.items('attendance').where((r)=>r['date']==today).toList();
    final present=marks.where((r)=>r['status']=='PRESENTE'||r['status']=='TARDANZA').length;
    final unjust=marks.where((r)=>r['status']=='AUSENTE_INJUST').length;
    final faults=controller.items('faults').where((r)=>r['end']==null||r['end']=='').length;
    final tickets=controller.items('tickets').where((r)=>r['status']=='ABIERTO').length;
    final groups=<String,int>{for(final c in categories)c:controller.activeOperators.where((r)=>r['category']==c).length};
    final total=controller.activeOperators.length;
    return ListView(children:[
      header('Resumen operacional','Hoy ${prettyDate(today)} · datos almacenados únicamente en este teléfono'),
      LayoutBuilder(builder:(ctx,box)=>GridView.count(
        crossAxisCount:box.maxWidth>720?4:2,childAspectRatio:box.maxWidth>720?2.1:1.65,
        shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),children:[
          statCard('Operadores activos',total,Icons.people),statCard('Presentes hoy',present,Icons.check_circle_outline),
          statCard('Ausencias injust.',unjust,Icons.person_off),statCard('Averías abiertas',faults,Icons.build_circle_outlined),
        ])),
      Card(child:Padding(padding:const EdgeInsets.all(17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Dotación por tipo de equipo',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:18),
        for(final entry in groups.entries)Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(entry.key),Text('${entry.value}')]),const SizedBox(height:5),
          LinearProgressIndicator(value:total==0?0:entry.value/total,minHeight:10,borderRadius:BorderRadius.circular(9)),
        ])),
      ]))),
      Card(child:ListTile(leading:const Icon(Icons.gavel),title:Text('$tickets infracciones abiertas'),subtitle:const Text('Los tickets se registran con supervisor, estado y reincidencia'))),
      Card(child:ListTile(leading:const Icon(Icons.calendar_today),title:Text('${controller.items('schedules').where((r)=>r['date']==formatDay(DateTime.now().add(const Duration(days:1)))).length} asignaciones para mañana'),subtitle:const Text('Incluye programación de domingos y feriados'))),
      const Padding(padding:EdgeInsets.all(12),child:Text('ControlOPS no dispone de sincronización multiusuario. Realiza respaldos JSON desde Respaldos.',style:TextStyle(color:Colors.blueGrey,fontSize:12))),
    ]);
  }
}
