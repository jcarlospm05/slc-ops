import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import '../core/office_export.dart';
import '../core/ticket_image.dart';
import 'common.dart';

class RecordsView extends StatelessWidget{
  const RecordsView({super.key,required this.controller,required this.entity});
  final OpsController controller;
  final String entity;
  String title(Map<String,dynamic> r) {switch(entity){
    case 'operators':return '${r['name']??''} · ${r['category']??''}';
    case 'assets':return '${r['code']??''} · ${r['category']??''}';
    case 'tickets':return '${controller.operatorName(r['operatorId'])} · ${r['level']??''}';
    case 'daysOff':return '${controller.operatorName(r['operatorId'])} · ${r['type']??''}';
    case 'faults':return '${controller.assetName(r['assetId'])} · ${r['end']?.toString().isNotEmpty==true?'Cerrada':'Abierta'}';
    case 'holidays':return '${r['name']??''}';
  }return '';
  }
  String secondary(Map<String,dynamic> r){
    if(entity=='faults'){
      final start=DateTime.tryParse('${r['start']??''}');
      final end=DateTime.tryParse('${r['end']??''}')??DateTime.now();
      final hours=start==null?0:(end.difference(start).inMinutes/60).clamp(0,100000);
      return '${r['start']??''} · ${hours.toStringAsFixed(1)} h fuera · ${r['description']??''}';
    }
    return '${r['date']??r['code']??''} · ${r['reason']??r['status']??r['notes']??r['description']??''}';
  }
  Future<void> edit(BuildContext ctx,[Map<String,dynamic>? record])async{
    final saved=await showDialog<bool>(context:ctx,builder:(context)=>RecordEditor(controller:controller,entity:entity,existing:record));
    if(saved==true&&ctx.mounted)message(ctx,'Registro guardado');
  }
  @override Widget build(BuildContext context){
    final items=controller.items(entity);
    return Column(children:[
      header(labels[entity]??entity,'${items.length} registros · almacenamiento SQLite local'),
      Align(alignment:Alignment.centerRight,child:FilledButton.icon(onPressed:()=>edit(context),icon:const Icon(Icons.add),label:const Text('Agregar'))),
      const SizedBox(height:9),
      Expanded(child:items.isEmpty?emptyState('No hay registros. Presiona Agregar.'):ListView.builder(itemCount:items.length,itemBuilder:(ctx,i){
        final item=items[i];return Card(child:ListTile(title:Text(title(item)),subtitle:Text(secondary(item),maxLines:2,overflow:TextOverflow.ellipsis),
          trailing:PopupMenuButton<String>(onSelected:(action)async{
            if(action=='edit'){await edit(ctx,item);return;}
            if(action=='jpg'){
              try{final jpg=await TicketImage.saveJpg(item,controller.operatorName(item['operatorId']));if(ctx.mounted)message(ctx,'Ticket JPG guardado; elige WhatsApp u otro destino.');await SharePlus.instance.share(ShareParams(files:[XFile(jpg.path)],text:'Ticket ControlOPS'));}
              catch(e){if(ctx.mounted)message(ctx,'Error JPG: $e',error:true);}return;
            }
            if(action=='delete'){
              if(!await confirm(ctx,'¿Eliminar este registro? Se guardará una entrada de auditoría local.'))return;
              try{await controller.remove(entity,'${item['id']}');if(ctx.mounted)message(ctx,'Registro eliminado');}
              catch(e){if(ctx.mounted)message(ctx,'No se eliminó: $e',error:true);}
            }
          },itemBuilder:(context)=>[
            const PopupMenuItem(value:'edit',child:Text('Editar')),
            if(entity=='tickets')const PopupMenuItem(value:'jpg',child:Text('Generar ticket JPG')),
            const PopupMenuItem(value:'delete',child:Text('Eliminar')),
          ])),
        );
      })),
    ]);
  }
}
class RecordEditor extends StatefulWidget{
  const RecordEditor({super.key,required this.controller,required this.entity,this.existing});
  final OpsController controller;
  final String entity;
  final Map<String,dynamic>? existing;
  @override State<RecordEditor> createState()=>_RecordEditorState();
}
class _RecordEditorState extends State<RecordEditor>{
  final formKey=GlobalKey<FormState>();
  final values=<String,dynamic>{};
  final ctrls=<String,TextEditingController>{};
  late final List<FieldSpec> specs;
  bool saving=false;
  @override void initState(){super.initState();
    specs=generalSpecs[widget.entity]!;
    values.addAll(widget.existing??{});
    for(final f in specs){
      dynamic defaultValue='';
      if(f.kind=='date')defaultValue=formatDay(DateTime.now());
      if(f.kind=='datetime'&&f.key=='start')defaultValue=formatTime(DateTime.now());
      if(f.kind=='choice')defaultValue=f.choices.keys.first;
      if(f.kind=='bool')defaultValue=true;
      if(f.key=='status')defaultValue='ABIERTO';
      values.putIfAbsent(f.key,()=>defaultValue);
      if(!['choice','operator','asset','bool'].contains(f.kind))ctrls[f.key]=TextEditingController(text:'${values[f.key]??''}');
    }
  }
  @override void dispose(){for(final c in ctrls.values){c.dispose();}super.dispose();}
  Widget _field(FieldSpec f){
    if(f.kind=='bool')return SwitchListTile(title:Text(f.title),value:values[f.key]!=false,onChanged:(v)=>setState(()=>values[f.key]=v));
    if(['choice','operator','asset'].contains(f.kind)){
      final choices=f.kind=='operator'?{for(final r in widget.controller.items('operators'))'${r['id']}':'${r['name']} · ${r['category']}'}:
        f.kind=='asset'?{for(final r in widget.controller.items('assets'))'${r['id']}':'${r['code']}'}:f.choices;
      final keys=<String,String>{if(!f.required) '':'(Ninguno)',...choices};
      final current=keys.containsKey(values[f.key])?'${values[f.key]}':(f.required&&choices.isNotEmpty?choices.keys.first:'');
      values[f.key]=current;
      return DropdownButtonFormField<String>(value:current,decoration:InputDecoration(labelText:f.title,border:const OutlineInputBorder()),
        isExpanded:true,items:keys.entries.map((v)=>DropdownMenuItem(value:v.key,child:Text(v.value,overflow:TextOverflow.ellipsis))).toList(),
        validator:(v)=>f.required && (v==null||v.isEmpty)?'Obligatorio':null,onChanged:(v)=>setState(()=>values[f.key]=v??''));
    }
    final c=ctrls[f.key]!;
    return TextFormField(controller:c,maxLines:f.long?3:1,keyboardType:f.kind=='number'?TextInputType.number:TextInputType.text,
      readOnly:f.kind=='date',maxLength:f.long?1500:300,
      decoration:InputDecoration(labelText:f.title,border:const OutlineInputBorder(),suffixIcon:f.kind=='date'?IconButton(onPressed:()async{
        final d=await chooseDate(context,c.text);if(d!=null){c.text=d;}
      },icon:const Icon(Icons.calendar_today)):null),
      validator:(text){
        if(f.required&&(text==null||text.trim().isEmpty))return 'Obligatorio';
        if(f.kind=='number'&&text!=null&&text.isNotEmpty&&num.tryParse(text)==null)return 'Número inválido';
        if(f.kind=='datetime'&&text!=null&&text.isNotEmpty&&DateTime.tryParse(text)==null)return 'Usa AAAA-MM-DDTHH:MM';
        return null;
      });
  }
  Future<void> save()async{
    if(!formKey.currentState!.validate())return;
    setState(()=>saving=true);
    for(final f in specs){
      if(ctrls.containsKey(f.key))values[f.key]=ctrls[f.key]!.text.trim();
    }
    values['id']=widget.existing?['id']??newId();
    if(widget.entity=='tickets'){
      values['reincidences']=widget.controller.items('tickets').where((r)=>r['operatorId']==values['operatorId'] && r['id']!=values['id'] && r['status']!='ANULADO' && '${r['date']}'.compareTo('${values['date']}')<=0).length;
      values['createdAt']=widget.existing?['createdAt']??DateTime.now().toUtc().toIso8601String();
    }
    try{
      await widget.controller.put(widget.entity,values);
      if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)message(context,'Error al guardar: $e',error:true);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context){
    return Dialog(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:620,maxHeight:760),child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Expanded(child:Text(widget.existing==null?'Nuevo registro · ${labels[widget.entity]}':'Editar registro · ${labels[widget.entity]}',style:const TextStyle(fontSize:19,fontWeight:FontWeight.w700))),IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close))]),
      const SizedBox(height:12),Expanded(child:Form(key:formKey,child:ListView(children:[for(final f in specs)Padding(padding:const EdgeInsets.only(bottom:12),child:_field(f))]))),
      Row(mainAxisAlignment:MainAxisAlignment.end,children:[TextButton(onPressed:saving?null:()=>Navigator.pop(context),child:const Text('Cancelar')),
        FilledButton(onPressed:saving?null:save,child:Text(saving?'Guardando…':'Guardar'))]),
    ]))));
  }
}
