import 'package:flutter/material.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import 'common.dart';

class AttendanceView extends StatefulWidget{
  const AttendanceView({super.key,required this.controller});
  final OpsController controller;
  @override State<AttendanceView> createState()=>_AttendanceViewState();
}
class _AttendanceViewState extends State<AttendanceView>{
  String date=formatDay(DateTime.now()),category='Todos';
  Future<void> mark(Map<String,dynamic> op)async{
    final old=widget.controller.items('attendance').where((r)=>r['date']==date&&r['operatorId']==op['id']).firstOrNull;
    final status=ValueNotifier<String>('${old?['status']??'PRESENTE'}');
    final start=TextEditingController(text:'${old?['start']??''}');
    final end=TextEditingController(text:'${old?['end']??''}');
    final notes=TextEditingController(text:'${old?['notes']??''}');
    try{
      final saved=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
        title:Text('Asistencia · ${op['name']}'),
        content:SizedBox(width:400,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
          ValueListenableBuilder<String>(valueListenable:status,builder:(ctx,val,_)=>DropdownButtonFormField<String>(value:val,isExpanded:true,
            decoration:const InputDecoration(labelText:'Estado'),items:attendanceStates.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v)=>status.value=v??'PRESENTE')),
          TextField(controller:start,decoration:const InputDecoration(labelText:'Hora entrada (HH:MM)')),
          TextField(controller:end,decoration:const InputDecoration(labelText:'Hora salida (HH:MM)')),
          TextField(controller:notes,maxLines:2,decoration:const InputDecoration(labelText:'Observaciones')),
        ]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Guardar'))]));
      if(saved==true){
        await widget.controller.put('attendance',{'id':old?['id']??newId(),'date':date,'operatorId':op['id'],'status':status.value,
          'start':start.text.trim(),'end':end.text.trim(),'notes':notes.text.trim(), 'updatedAt':DateTime.now().toUtc().toIso8601String()});
        if(mounted)message(context,'Marcación guardada');
      }
    }catch(e){if(mounted)message(context,'Error: $e',error:true);}
    finally{status.dispose();start.dispose();end.dispose();notes.dispose();}
  }
  Future<void> markAll()async{
    if(!await confirm(context,'¿Marcar PRESENTE a los operadores visibles sin marcación?'))return;
    try{
      int count=0;
      for(final op in widget.controller.activeOperators.where((r)=>category=='Todos'||r['category']==category)){
        final any=widget.controller.items('attendance').any((r)=>r['date']==date&&r['operatorId']==op['id']);
        if(!any){await widget.controller.put('attendance',{'id':newId(),'date':date,'operatorId':op['id'],'status':'PRESENTE','start':'','end':'','notes':''});count++;}
      }
      if(mounted)message(context,'Marcados $count operadores');
    }catch(e){if(mounted)message(context,'Error: $e',error:true);}
  }
  @override Widget build(BuildContext context){
    final list=widget.controller.activeOperators.where((r)=>category=='Todos'||r['category']==category).toList();
    final statuses=widget.controller.items('attendance');
    return Column(children:[
      header('Control de asistencia','Marcación por operador, fecha y tipo de equipo.'),
      Wrap(spacing:8,runSpacing:8,children:[
        OutlinedButton.icon(onPressed:()async{final next=await chooseDate(context,date);if(next!=null)setState(()=>date=next);},icon:const Icon(Icons.event),label:Text(prettyDate(date))),
        DropdownButton<String>(value:category,items:['Todos',...categories].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>category=v??'Todos')),
        FilledButton.icon(onPressed:markAll,icon:const Icon(Icons.done_all),label:const Text('Presentes sin marcar')),
      ]),const SizedBox(height:8),
      Expanded(child:list.isEmpty?emptyState('Agrega operadores en el maestro de personal.'):ListView.builder(itemCount:list.length,itemBuilder:(ctx,i){
        final op=list[i];final found=statuses.where((r)=>r['operatorId']==op['id']&&r['date']==date).firstOrNull;
        return Card(child:ListTile(title:Text('${op['name']}'),subtitle:Text('${op['category']} · ${found==null?'SIN MARCAR':attendanceStates[found['status']]??found['status']}'),
          trailing:const Icon(Icons.edit_outlined),onTap:()=>mark(op)));
      })),
    ]);
  }
}
