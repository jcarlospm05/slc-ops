import 'package:flutter/material.dart';
import '../core/controller.dart';
import 'common.dart';
import 'dashboard_view.dart';
import 'records_view.dart';
import 'attendance_view.dart';
import 'schedule_view.dart';
import 'meals_view.dart';
import 'reports_view.dart';
import 'backup_view.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key,required this.controller});
  final OpsController controller;
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell>{
  int page=0;
  static const entries=<({String text,IconData icon})>[
    (text:'Dashboard',icon:Icons.dashboard_outlined),
    (text:'Operadores',icon:Icons.badge_outlined),
    (text:'Asistencia',icon:Icons.fact_check_outlined),
    (text:'Infracciones',icon:Icons.gavel_outlined),
    (text:'Días libres',icon:Icons.event_available_outlined),
    (text:'Programación',icon:Icons.calendar_month_outlined),
    (text:'Comidas',icon:Icons.restaurant_outlined),
    (text:'Equipos',icon:Icons.precision_manufacturing_outlined),
    (text:'Averías',icon:Icons.build_outlined),
    (text:'Feriados',icon:Icons.event_outlined),
    (text:'Reportes',icon:Icons.bar_chart_outlined),
    (text:'Respaldos',icon:Icons.save_alt_outlined),
  ];
  Widget selected(){switch(page){
    case 0:return DashboardView(controller:widget.controller);
    case 1:return RecordsView(key:const ValueKey('operators'),controller:widget.controller,entity:'operators');
    case 2:return AttendanceView(controller:widget.controller);
    case 3:return RecordsView(key:const ValueKey('tickets'),controller:widget.controller,entity:'tickets');
    case 4:return RecordsView(key:const ValueKey('daysOff'),controller:widget.controller,entity:'daysOff');
    case 5:return ScheduleView(controller:widget.controller);
    case 6:return MealsView(controller:widget.controller);
    case 7:return RecordsView(key:const ValueKey('assets'),controller:widget.controller,entity:'assets');
    case 8:return RecordsView(key:const ValueKey('faults'),controller:widget.controller,entity:'faults');
    case 9:return RecordsView(key:const ValueKey('holidays'),controller:widget.controller,entity:'holidays');
    case 10:return ReportsView(controller:widget.controller);
    default:return BackupView(controller:widget.controller);
  }}
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:widget.controller,builder:(context,_) {
    if(widget.controller.busy)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(widget.controller.error!=null)return Scaffold(body:Center(child:Text('Error al abrir SQLite: ${widget.controller.error}')));
    final wide=MediaQuery.sizeOf(context).width>=860;
    Widget nav()=>ListView(children:[
      const ListTile(title:Text('CONTROL OPS',style:TextStyle(fontWeight:FontWeight.w900,color:Colors.indigo))),
      for(var i=0;i<entries.length;i++)ListTile(
        leading:Icon(entries[i].icon),title:Text(entries[i].text),selected:page==i,
        onTap:(){setState(()=>page=i);if(!wide)Navigator.pop(context);},
      ),
      const Divider(),const Padding(padding:EdgeInsets.all(12),child:Text('SQLite local · sin conexión',style:TextStyle(fontSize:11,color:Colors.blueGrey))),
    ]);
    return Scaffold(
      appBar:AppBar(title:Text(entries[page].text),backgroundColor:Colors.white,
        actions:[IconButton(onPressed:()async{try{await widget.controller.refresh();if(context.mounted)message(context,'Datos actualizados');}catch(e){if(context.mounted)message(context,e.toString(),error:true);}},icon:const Icon(Icons.refresh),tooltip:'Actualizar')]),
      drawer:wide?null:Drawer(child:SafeArea(child:nav())),
      body:Row(children:[
        if(wide)SizedBox(width:230,child:Material(color:Colors.white,child:SafeArea(child:nav()))),
        Expanded(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:1200),child:Padding(padding:const EdgeInsets.all(14),child:selected())))),
      ]),
    );
  });
}
