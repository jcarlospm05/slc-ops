import 'package:flutter/material.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import '../core/security.dart';
import 'common.dart';

class MealsView extends StatefulWidget{
  const MealsView({super.key,required this.controller});
  final OpsController controller;
  @override State<MealsView> createState()=>_MealsViewState();
}
class _MealsViewState extends State<MealsView>{
  String date=formatDay(DateTime.now()),type='CENA';
  Set<String> selected={};
  final notes=TextEditingController();
  bool initialized=false;
  @override void initState(){super.initState();_reload();}
  void _reload(){selected=widget.controller.items('meals').where((r)=>r['date']==date&&r['type']==type).map((r)=>'${r['operatorId']}').toSet();
    notes.text='${widget.controller.items('meals').where((r)=>r['date']==date&&r['type']==type).firstOrNull?['notes']??''}';
  }
  @override void dispose(){notes.dispose();super.dispose();}
  Future<void> save()async{
    try{await widget.controller.replaceMeals(date,type,selected.toList(),notes.text.trim());if(mounted)message(context,'Solicitud de $type guardada: ${selected.length} operadores');}
    catch(e){if(mounted)message(context,'Error: $e',error:true);}
  }
  @override Widget build(BuildContext context){
    final valid=type=='CENA'||isLunchAllowed(date,widget.controller.items('holidays').map((h)=>'${h['date']}'));
    final ops=widget.controller.activeOperators;
    return Column(children:[
      header('Solicitud de comidas','Cena diaria y almuerzo los sábados, domingos o feriados.'),
      Wrap(spacing:8,runSpacing:8,children:[
        OutlinedButton.icon(onPressed:()async{final d=await chooseDate(context,date);if(d!=null)setState((){date=d;_reload();});},icon:const Icon(Icons.event),label:Text(prettyDate(date))),
        DropdownButton<String>(value:type,items:const [DropdownMenuItem(value:'CENA',child:Text('Cena')),DropdownMenuItem(value:'ALMUERZO',child:Text('Almuerzo'))],onChanged:(v)=>setState((){type=v??'CENA';_reload();})),
        TextButton(onPressed:()=>setState(()=>selected=ops.map((o)=>'${o['id']}').toSet()),child:const Text('Todos')),
        TextButton(onPressed:()=>setState(()=>selected.clear()),child:const Text('Ninguno')),
      ]),
      if(!valid)const Card(child:ListTile(leading:Icon(Icons.warning_amber),title:Text('Almuerzo permitido solo sábado, domingo o feriado registrado.'))),
      TextField(controller:notes,maxLength:220,decoration:const InputDecoration(labelText:'Observaciones de la solicitud')),
      Align(alignment:Alignment.centerLeft,child:Text('${selected.length} operadores seleccionados',style:const TextStyle(fontWeight:FontWeight.bold))),
      Expanded(child:ListView(children:[for(final op in ops)Card(child:CheckboxListTile(
        value:selected.contains(op['id']),title:Text('${op['name']}'),subtitle:Text('${op['category']}'),
        onChanged:(v)=>setState((){if(v==true){selected.add('${op['id']}');}else{selected.remove('${op['id']}');}}),
      ))])),
      SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:valid?save:null,icon:const Icon(Icons.save),label:const Text('Guardar solicitud'))),
    ]);
  }
}
