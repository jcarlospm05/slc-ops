import 'package:flutter/material.dart';
import '../core/catalog.dart';
import '../core/controller.dart';
import 'common.dart';

class ScheduleView extends StatefulWidget{
  const ScheduleView({super.key,required this.controller});
  final OpsController controller;
  @override State<ScheduleView> createState()=>_ScheduleViewState();
}
class _ScheduleViewState extends State<ScheduleView>{
  String date=formatDay(DateTime.now().add(const Duration(days:1)));
  Future<void> edit(Map<String,dynamic> op)async {
    final old=widget.controller.items('schedules').where((r)=>r['operatorId']==op['id']&&r['date']==date).firstOrNull;
    final task=TextEditingController(text:'${old?['task']??''}');
    final start=TextEditingController(text:'${old?['start']??'07:00'}');
    final end=TextEditingController(text:'${old?['end']??'16:00'}');
    final place=TextEditingController(text:'${old?['place']??''}');
    var assetId='${old?['assetId']??''}';
    try {
      final saved=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,change)=>AlertDialog(
        title:Text('Turno · ${op['name']}'),
        content:SizedBox(width:430,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:start,decoration:const InputDecoration(labelText:'Entrada (HH:MM)')),
          TextField(controller:end,decoration:const InputDecoration(labelText:'Salida (HH:MM)')),
          TextField(controller:task,decoration:const InputDecoration(labelText:'Tarea a realizar')),
          TextField(controller:place,decoration:const InputDecoration(labelText:'Área / ubicación')),
          DropdownButtonFormField<String>(value:widget.controller.items('assets').any((e)=>e['id']==assetId)?assetId:'',
            decoration:const InputDecoration(labelText:'Equipo asignado'),items:[
              const DropdownMenuItem(value:'',child:Text('Sin asignación')),
              ...widget.controller.items('assets').map((e)=>DropdownMenuItem(value:'${e['id']}',child:Text('${e['code']}'))),
            ],onChanged:(v)=>change(()=>assetId=v??'')),
        ]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Guardar'))])));
      if(saved==true){
        final d={'id':old?['id']??newId(),'date':date,'operatorId':op['id'],'start':start.text.trim(),'end':end.text.trim(),
          'task':task.text.trim(),'place':place.text.trim(),'assetId':assetId};
        await widget.controller.put('schedules',d);
        if(mounted)message(context,'Turno guardado');
      }
    }catch(e){if(mounted)message(context,'No se pudo guardar: $e',error:true);}
    finally{task.dispose();start.dispose();end.dispose();place.dispose();}
  }
  @override Widget build(BuildContext context){
    final day=DateTime.tryParse(date);
    final special=(day?.weekday==DateTime.sunday)||widget.controller.items('holidays').any((h)=>h['date']==date);
    final schedules=widget.controller.items('schedules');
    return Column(children:[
      header('Programación de operadores','Asignación de tareas, equipos y horarios para mañana, domingos o feriados.'),
      Wrap(spacing:8,runSpacing:8,children:[
        OutlinedButton.icon(onPressed:()async{final d=await chooseDate(context,date);if(d!=null)setState(()=>date=d);},icon:const Icon(Icons.event),label:Text(prettyDate(date))),
        OutlinedButton(onPressed:()=>setState(()=>date=formatDay(DateTime.now().add(const Duration(days:1)))),child:const Text('Mañana')),
        OutlinedButton(onPressed:(){final now=DateTime.now();final delta=7-now.weekday;setState(()=>date=formatDay(now.add(Duration(days:delta==0?7:delta))));},child:const Text('Domingo próximo')),
      ]),
      if(special)const Card(child:ListTile(leading:Icon(Icons.event_available,color:Colors.deepOrange),title:Text('Programación especial: domingo o feriado'))),
      const SizedBox(height:8),
      Expanded(child:widget.controller.activeOperators.isEmpty?emptyState('No hay operadores'):ListView.builder(itemCount:widget.controller.activeOperators.length,itemBuilder:(ctx,i){
        final op=widget.controller.activeOperators[i];
        final current=schedules.where((s)=>s['operatorId']==op['id']&&s['date']==date).firstOrNull;
        return Card(child:ListTile(title:Text('${op['name']}'),
          subtitle:Text(current==null?'Sin asignar':'${current['start']}–${current['end']} · ${current['task']} · ${current['place']}'),
          leading:const Icon(Icons.schedule),trailing:const Icon(Icons.edit),onTap:()=>edit(op)));
      })),
    ]);
  }
}
