import 'dart:convert';
import 'dart:typed_data';
import 'catalog.dart';
import 'security.dart';

class BackupService {
  static Uint8List encode(Map<String,List<Map<String,dynamic>>> snapshot) {
    final payload={'format':'CONTROL_OPS_SQLITE_EXPORT','version':1,'exportedAt':DateTime.now().toUtc().toIso8601String(),
      'collections':{for(final entity in entities)entity:snapshot[entity]??[]}};
    return Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(payload)));
  }
  static Map<String,List<Map<String,dynamic>>> parse(Uint8List bytes){
    if(bytes.length>8*1024*1024)throw const DataValidationException('Respaldo mayor a 8 MB');
    final decoded=jsonDecode(utf8.decode(bytes));
    if(decoded is! Map)throw const DataValidationException('JSON raíz inválido');
    final root=Map<String,dynamic>.from(decoded);
    // Puede importar respaldo completo de ControlOPS web v1/v2 o exportación Flutter.
    final payload=root['collections'] is Map?Map<String,dynamic>.from(root['collections'] as Map):root;
    final result=<String,List<Map<String,dynamic>>>{};
    var count=0;
    for(final e in entities){
      final source=payload[e];
      if(source is! List)throw DataValidationException('No existe el conjunto $e');
      final list=<Map<String,dynamic>>[];
      for(final item in source){
        if(item is! Map)throw const DataValidationException('Registro inválido');
        list.add(validatedRecord(e,Map<String,dynamic>.from(item)));
        if(++count>100000)throw const DataValidationException('Demasiados registros');
      }
      result[e]=list;
    }
    return result;
  }
}
