import 'dart:typed_data';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:image/image.dart' as img;
import 'office_export.dart';

class TicketImage {
  static void _txt(ui.Canvas c,String t,double x,double y,{double size=26,bool strong=false,double width=790}){
    final builder=ui.ParagraphBuilder(ui.ParagraphStyle(fontSize:size,maxLines:7))
      ..pushStyle(ui.TextStyle(color:const ui.Color(0xFF152D4A),fontSize:size,fontWeight:strong?ui.FontWeight.w700:ui.FontWeight.w400))
      ..addText(t);
    final p=builder.build()..layout(ui.ParagraphConstraints(width:width));
    c.drawParagraph(p,ui.Offset(x,y));
  }
  static Future<File> saveJpg(Map<String,dynamic> t,String operator)async {
    final recorder=ui.PictureRecorder();final canvas=ui.Canvas(recorder);
    canvas.drawColor(const ui.Color(0xFFFFFFFF),ui.BlendMode.src);
    canvas.drawRect(const ui.Rect.fromLTWH(0,0,900,115),ui.Paint()..color=const ui.Color(0xFF1D4ED8));
    _txt(canvas,'DEPARTAMENTO DE OPERACIONES',35,31,size:29,strong:true);
    _txt(canvas,'TICKET DE INFRACCIÓN',35,150,strong:true,size:34);
    final fields=[
      ['Fecha','${t['date']??''}'],['Operador',operator],['Motivo','${t['reason']??''}'],
      ['Nivel','${t['level']??''}'],['Estado','${t['status']??''}'],
      ['Supervisor','${t['supervisor']??''}'],
      ['Reincidencias','${t['reincidences']??0}'],
      ['Objetivo / Real','${t['expected']??'-'} / ${t['actual']??'-'}'],
    ];
    for(var i=0;i<fields.length;i++){
      final y=215.0+i*67;
      _txt(canvas,fields[i][0],35,y,size:18,strong:true,width:230);
      _txt(canvas,fields[i][1],250,y,size:20,width:610);
      canvas.drawLine(ui.Offset(35,y+42),ui.Offset(865,y+42),ui.Paint()..color=const ui.Color(0xFFE3EAF4));
    }
    _txt(canvas,'DESCRIPCIÓN',35,770,size:20,strong:true);
    _txt(canvas,'${t['description']??''}',35,810,size:22,width:820);
    final pic=recorder.endRecording();final image=await pic.toImage(900,1080);
    final bytes=await image.toByteData(format:ui.ImageByteFormat.png);
    image.dispose();pic.dispose();
    if(bytes==null)throw Exception('No fue posible generar ticket');
    final decoded=img.decodePng(bytes.buffer.asUint8List());
    if(decoded==null)throw Exception('PNG inválido');
    return OfficeExport.save('Ticket_${t['date']??'fecha'}_${t['id']}.jpg',Uint8List.fromList(img.encodeJpg(decoded,quality:91)));
  }
}
