import 'catalog.dart';

class DataValidationException implements Exception {
  const DataValidationException(this.message);
  final String message;
  @override String toString()=>message;
}

/// Rechaza estructuras y tamaños peligrosos antes de escribir en SQLite.
Map<String,dynamic> validatedRecord(String entity, Map<String,dynamic> source) {
  if (!entities.contains(entity)) throw const DataValidationException('Módulo desconocido');
  final data=<String,dynamic>{};
  for(final entry in source.entries) {
    if(entry.key.length>64 || !RegExp(r'^[A-Za-z][A-Za-z0-9_]*$').hasMatch(entry.key)) {
      throw const DataValidationException('Campo no válido');
    }
    final v=entry.value;
    if(v is String) {
      if(v.length>3000 || v.contains('\u0000')) throw const DataValidationException('Campo de texto demasiado largo o inválido');
      data[entry.key]=v.trim();
    } else if(v is bool || v is num || v == null) {
      data[entry.key]=v;
    } else {throw const DataValidationException('Tipo de dato no permitido');}
  }
  if((data['id']??'').toString().length>100)throw const DataValidationException('ID inválido');
  if(data['date']!=null && !RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(data['date'].toString()))throw const DataValidationException('Fecha no válida');
  if(data['category']!=null && !categories.contains(data['category']))throw const DataValidationException('Categoría incorrecta');
  if(entity=='attendance' && data['status']!=null && !attendanceStates.containsKey(data['status']))throw const DataValidationException('Estado de asistencia incorrecto');
  if(entity=='tickets') {
    if(!ticketReasons.containsKey(data['reason']) || !ticketLevels.contains(data['level']) ||
       !['ABIERTO','CERRADO','ESCALADO','ANULADO'].contains(data['status']))throw const DataValidationException('Ticket con campos inválidos');
  }
  if(entity=='daysOff' && data['type']!=null && !offTypes.contains(data['type']))throw const DataValidationException('Día libre incorrecto');
  if(entity=='meals' && !['CENA','ALMUERZO'].contains(data['type']))throw const DataValidationException('Tipo de comida incorrecto');
  if(entity=='faults') {
    final a=DateTime.tryParse((data['start']??'').toString());
    final b=DateTime.tryParse((data['end']??'').toString());
    if(a==null || (data['end']?.toString().isNotEmpty==true && b==null) || (b!=null && b.isBefore(a)))throw const DataValidationException('Intervalo de avería inválido');
  }
  return data;
}

bool isLunchAllowed(String date, Iterable<String> holidays) {
  final day=DateTime.tryParse(date);
  return day!=null && (day.weekday>=6 || holidays.contains(date));
}

/// Evita ejecución de fórmulas cuando un CSV se abre en Excel.
String csvCell(Object? value) {
  var text=(value??'').toString().replaceAll('\u0000','');
  if(RegExp(r'^[\s\uFEFF\u200B]*[=+@\-]').hasMatch(text))text="'$text";
  return '"${text.replaceAll('"','""')}"';
}
String xmlEscape(Object? value) => (value??'').toString()
  .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
  .replaceAll('"','&quot;').replaceAll("'",'&apos;');
String officeCell(Object? value) {
  var text=(value??'').toString();
  if(RegExp(r'^[\s\uFEFF\u200B]*[=+@]').hasMatch(text))text="'$text";
  return text;
}
