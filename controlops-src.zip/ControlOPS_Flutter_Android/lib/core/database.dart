import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'catalog.dart';
import 'security.dart';

/// SQLite es la fuente de verdad en el teléfono; Drive contiene SOLO código.
/// Almacenamiento flexible pero indexado para migrar desde ControlOPS web.
class LocalDatabase {
  Database? _db;
  Future<Database> get instance async {
    if(_db!=null)return _db!;
    final location=p.join(await getDatabasesPath(),'controlops.sqlite');
    _db=await openDatabase(location,version:1,onConfigure:(db)async {
      await db.execute('PRAGMA foreign_keys = ON');
    },onCreate:(db,version)async {
      await db.execute('''CREATE TABLE records (
        entity TEXT NOT NULL, id TEXT NOT NULL, operator_id TEXT,
        service_date TEXT, variant TEXT, unique_key TEXT, payload TEXT NOT NULL,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        PRIMARY KEY(entity,id), UNIQUE(entity,unique_key))''');
      await db.execute('CREATE INDEX idx_records_entity_date ON records(entity,service_date)');
      await db.execute('CREATE INDEX idx_records_operator ON records(entity,operator_id)');
      await db.execute('''CREATE TABLE audit_log (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
        action TEXT NOT NULL, entity TEXT NOT NULL, record_id TEXT NOT NULL,
        previous_json TEXT, next_json TEXT)''');
    });
    return _db!;
  }

  Future<List<Map<String,dynamic>>> list(String entity) async {
    if(!entities.contains(entity)) throw const DataValidationException('Entidad desconocida');
    final db=await instance;
    final rows=await db.query('records',columns:['payload'],where:'entity = ?',whereArgs:[entity],orderBy:'service_date DESC, updated_at DESC');
    return rows.map((e)=>Map<String,dynamic>.from(jsonDecode(e['payload'] as String) as Map)).toList();
  }
  Future<Map<String,dynamic>?> one(String entity,String id) async {
    final db=await instance;
    final r=await db.query('records',columns:['payload'],where:'entity = ? AND id = ?',whereArgs:[entity,id],limit:1);
    return r.isEmpty?null:Map<String,dynamic>.from(jsonDecode(r.first['payload'] as String) as Map);
  }
  String? _uniqueKey(String entity,Map<String,dynamic> data) {
    final op=(data['operatorId']??'').toString(), date=(data['date']??'').toString();
    switch(entity) {
      case 'operators':return (data['code']??'').toString().trim().toLowerCase().isNotEmpty ? data['code'].toString().trim().toLowerCase():null;
      case 'assets':return (data['code']??'').toString().trim().toLowerCase();
      case 'attendance':case 'daysOff':case 'schedules':return '$op|$date';
      case 'meals':return '$op|$date|${data['type']}';
      case 'holidays':return date;
    }
    return null;
  }
  Future<void> _write(Transaction txn,String entity,Map<String,dynamic> input,{bool log=true})async {
    final data=validatedRecord(entity,input);
    final id=(data['id']??'').toString();
    if(id.isEmpty)throw const DataValidationException('Identificador vacío');
    final now=DateTime.now().toUtc().toIso8601String();
    final old=await txn.query('records',columns:['payload','created_at'],where:'entity = ? AND id = ?',whereArgs:[entity,id],limit:1);
    final prior=old.isEmpty?null:old.first['payload'] as String;
    final created=old.isEmpty?now:old.first['created_at'] as String;
    final json=jsonEncode(data);
    await txn.insert('records',{
      'entity':entity,'id':id,'operator_id':data['operatorId']?.toString(),
      'service_date':data['date']?.toString() ?? data['start']?.toString().substring(0,10),
      'variant':data['type']?.toString(), 'unique_key':_uniqueKey(entity,data),
      'payload':json,'created_at':created,'updated_at':now,
    },conflictAlgorithm:ConflictAlgorithm.abort);
    if(log)await txn.insert('audit_log',{'timestamp':now,'action':prior==null?'CREATE':'UPDATE','entity':entity,'record_id':id,'previous_json':prior,'next_json':json});
  }
  /// UPDATE precisa preservar la unicidad de la clave compuesta.
  Future<void> put(String entity,Map<String,dynamic> data) async {
    final db=await instance;
    await db.transaction((txn)async {
      final input=Map<String,dynamic>.from(data);
      input.putIfAbsent('id',newId);
      final existing=await txn.query('records',columns:['id'],where:'entity = ? AND id = ?',whereArgs:[entity,input['id']],limit:1);
      if(existing.isNotEmpty) {
        final normalized=validatedRecord(entity,input);
        final now=DateTime.now().toUtc().toIso8601String();
        final old=await txn.query('records',columns:['payload'],where:'entity = ? AND id = ?',whereArgs:[entity,input['id']],limit:1);
        await txn.update('records',{
          'operator_id':normalized['operatorId']?.toString(),
          'service_date':normalized['date']?.toString() ?? normalized['start']?.toString().substring(0,10),
          'variant':normalized['type']?.toString(),'unique_key':_uniqueKey(entity,normalized),
          'payload':jsonEncode(normalized),'updated_at':now,
        },where:'entity = ? AND id = ?',whereArgs:[entity,input['id']]);
        await txn.insert('audit_log',{'timestamp':now,'action':'UPDATE','entity':entity,'record_id':input['id'],'previous_json':old.first['payload'],'next_json':jsonEncode(normalized)});
      } else {
        await _write(txn,entity,input);
      }
    });
  }
  Future<void> remove(String entity,String id) async {
    final db=await instance;
    await db.transaction((txn)async {
      final rows=await txn.query('records',columns:['payload'],where:'entity = ? AND id = ?',whereArgs:[entity,id],limit:1);
      if(rows.isEmpty)return;
      final old=rows.first['payload'] as String;
      if(entity=='operators' || entity=='assets'){
        final other=await txn.query('records',columns:['payload'],where:'entity != ?',whereArgs:[entity]);
        for(final r in other){
          final data=jsonDecode(r['payload'] as String) as Map;
          if(entity=='operators' && data['operatorId']==id || entity=='assets' && data['assetId']==id) {
            throw const DataValidationException('Hay registros asociados. Desactiva el operador o conserva el equipo.');
          }
        }
      }
      await txn.delete('records',where:'entity = ? AND id = ?',whereArgs:[entity,id]);
      await txn.insert('audit_log',{'timestamp':DateTime.now().toUtc().toIso8601String(),'action':'DELETE','entity':entity,'record_id':id,'previous_json':old,'next_json':null});
    });
  }
  Future<void> replaceMeals(String date,String type,List<String> operatorIds,String notes) async {
    final db=await instance;
    await db.transaction((txn)async {
      final old=await txn.query('records',where:'entity = ? AND service_date = ? AND variant = ?',whereArgs:['meals',date,type]);
      final current={for(final r in old)(jsonDecode(r['payload'] as String) as Map)['operatorId'].toString():r};
      for(final row in old){
        final record=jsonDecode(row['payload'] as String) as Map;
        if(!operatorIds.contains(record['operatorId'])){
          await txn.delete('records',where:'entity = ? AND id = ?',whereArgs:['meals',row['id']]);
          await txn.insert('audit_log',{'timestamp':DateTime.now().toUtc().toIso8601String(),'action':'DELETE','entity':'meals','record_id':row['id'],'previous_json':row['payload']});
        }
      }
      for(final op in operatorIds){
        final prior=current[op];
        final record={'id':prior?['id']??newId(),'date':date,'operatorId':op,'type':type,'notes':notes};
        if(prior!=null){
          final now=DateTime.now().toUtc().toIso8601String();
          await txn.update('records',{'payload':jsonEncode(record),'updated_at':now},where:'entity = ? AND id = ?',whereArgs:['meals',prior['id']]);
          await txn.insert('audit_log',{'timestamp':now,'action':'UPDATE','entity':'meals','record_id':prior['id'],'previous_json':prior['payload'],'next_json':jsonEncode(record)});
        }else{await _write(txn,'meals',record);}
      }
    });
  }
  Future<Map<String,List<Map<String,dynamic>>>> snapshot() async {
    final out=<String,List<Map<String,dynamic>>>{};
    for(final e in entities){out[e]=await list(e);}
    return out;
  }
  /// Reemplaza TODA la base o no altera nada. Respaldar primero.
  Future<void> restore(Map<String,List<Map<String,dynamic>>> data)async {
    final db=await instance;
    await db.transaction((txn)async {
      for(final e in entities){
        if(!data.containsKey(e))throw DataValidationException('Falta $e');
        if(data[e]!.length>50000)throw const DataValidationException('Demasiados registros');
        for(final item in data[e]!){validatedRecord(e,item);}
      }
      await txn.delete('records');
      for(final e in entities){
        for(final item in data[e]!){await _write(txn,e,item,log:false);}
      }
      await txn.insert('audit_log',{'timestamp':DateTime.now().toUtc().toIso8601String(),'action':'RESTORE','entity':'system','record_id':'all'});
    });
  }
  Future<int> auditCount() async {
    final db=await instance;
    final rows=await db.rawQuery('SELECT COUNT(*) AS n FROM audit_log');
    return Sqflite.firstIntValue(rows)??0;
  }
  Future<void> close()async{await _db?.close();_db=null;}
}
