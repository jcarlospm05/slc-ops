import 'catalog.dart';

class OpsReport {
  OpsReport({required this.title,required this.headers,required this.rows,required this.metrics,required this.from,required this.to});
  final String title,from,to;
  final List<String> headers;
  final List<List<Object?>> rows;
  final Map<String,double> metrics;
}
class ReportEngine {
  static const types=<String,String>{
    'asistencia':'Asistencia detallada','asistencia_resumen':'Conteo de asistencia',
    'tickets':'Infracciones emitidas','daysOff':'Días libres',
    'schedules':'Programación de operadores','meals':'Solicitudes de comidas',
    'faults':'Averías y tiempo fuera','operators':'Maestro de operadores',
    'assets':'Maestro de equipos',
  };
  static OpsReport make(Map<String,List<Map<String,dynamic>>> db,String type,String from,String to){
    if(!types.containsKey(type))throw ArgumentError('Tipo de reporte desconocido');
    final operators={for(final o in db['operators']??[])o['id']:'${o['name']}'};
    final assets={for(final a in db['assets']??[])a['id']:'${a['code']}'};
    final all=(db[type=='asistencia_resumen'?'attendance':type]??[]).where((r){
      if(type=='operators'||type=='assets')return true;
      final date='${r['date']??r['start']??''}';
      return date.compareTo(from)>=0 && date.compareTo('${to}T99')<=0;
    }).toList();
    List<String> h=[];
    List<List<Object?>> rows=[];
    Map<String,double> metrics={};
    String op(Map r)=>operators[r['operatorId']]??'No registrado';
    String asset(Map r)=>assets[r['assetId']]??'No registrado';
    if(type=='asistencia'){
      h=['Fecha','Operador','Marcación','Inicio','Fin','Observaciones'];
      rows=all.map((r)=>[r['date'],op(r),attendanceStates[r['status']]??r['status'],r['start'],r['end'],r['notes']]).toList();
      for(final r in all){final k=attendanceStates[r['status']]??'Sin marcar';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='asistencia_resumen'){
      h=['Operador','Presentes','Tardanzas','Aus. just.','Aus. injust.','Libres','Total'];
      for(final o in (db['operators']??[])){
        final own=all.where((a)=>a['operatorId']==o['id']);
        int n(String s)=>own.where((a)=>a['status']==s).length;
        rows.add([o['name'],n('PRESENTE'),n('TARDANZA'),n('AUSENTE_JUST'),n('AUSENTE_INJUST'),n('LIBRE'),own.length]);
      }
      metrics={'Presente':all.where((e)=>e['status']=='PRESENTE').length.toDouble(),
        'Tardanza':all.where((e)=>e['status']=='TARDANZA').length.toDouble(),
        'Injustificada':all.where((e)=>e['status']=='AUSENTE_INJUST').length.toDouble(),
        'Justificada':all.where((e)=>e['status']=='AUSENTE_JUST').length.toDouble(),
        'Libre':all.where((e)=>e['status']=='LIBRE').length.toDouble()};
    } else if(type=='tickets'){
      h=['Fecha','Operador','Motivo','Nivel','Estado','Supervisor','Objetivo','Real','Reincidencias','Descripción'];
      rows=all.map((r)=>[r['date'],op(r),ticketReasons[r['reason']]??r['reason'],r['level'],r['status'],r['supervisor'],r['expected'],r['actual'],r['reincidences']??0,r['description']]).toList();
      for(final r in all){final k=ticketReasons[r['reason']]??'Otro';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='daysOff'){
      h=['Fecha','Operador','Motivo','Observaciones'];rows=all.map((r)=>[r['date'],op(r),r['type'],r['notes']]).toList();
      for(final r in all){final k='${r['type']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='schedules'){
      h=['Fecha','Operador','Inicio','Fin','Tarea','Equipo','Área'];
      rows=all.map((r)=>[r['date'],op(r),r['start'],r['end'],r['task'],r['assetId']==null||r['assetId']==''?'':asset(r),r['place']]).toList();
      for(final r in all){final k= '${r['task']??'Sin tarea'}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='meals'){
      h=['Fecha','Operador','Servicio','Observaciones'];
      rows=all.map((r)=>[r['date'],op(r),r['type'],r['notes']]).toList();
      for(final r in all){final k='${r['type']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='faults'){
      h=['Equipo','Inicio','Fin','Horas fuera','Avería','Solución'];
      rows=all.map((r){final s=DateTime.tryParse('${r['start']??''}');final e=DateTime.tryParse('${r['end']??''}')??DateTime.now();
        final hours=(s==null?0.0:(e.difference(s).inMinutes/60).clamp(0.0,100000.0)).toDouble();
        final key=asset(r);metrics[key]=(metrics[key]??0)+hours;
        return [keyOr(r,assets),r['start'],r['end']??'Abierta',hours.toStringAsFixed(2),r['description'],r['notes']];
      }).toList();
    } else if(type=='operators'){
      h=['Ficha','Operador','Categoría','Activo','Observaciones'];
      rows=all.map((r)=>[r['code'],r['name'],r['category'],r['active']==false?'No':'Sí',r['notes']]).toList();
      for(final r in all){final k='${r['category']}';metrics[k]=(metrics[k]??0)+1;}
    } else if(type=='assets'){
      h=['Código','Categoría','Descripción'];rows=all.map((r)=>[r['code'],r['category'],r['description']]).toList();
      for(final r in all){final k='${r['category']}';metrics[k]=(metrics[k]??0)+1;}
    }
    return OpsReport(title:types[type]!,headers:h,rows:rows,metrics:metrics,from:from,to:to);
  }
  static String keyOr(Map r,Map assets)=>assets[r['assetId']]??'No registrado';
}
