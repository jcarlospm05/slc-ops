/// Catálogos y esquema visual; los módulos se pueden ampliar independientemente.
const entities = <String>[
  'operators', 'assets', 'attendance', 'tickets', 'daysOff',
  'schedules', 'meals', 'faults', 'holidays',
];
const categories = ['Mula', 'Grúa', 'Montacargas'];
const attendanceStates = {
  'PRESENTE': 'Presente', 'TARDANZA': 'Tardanza',
  'AUSENTE_JUST': 'Ausencia justificada',
  'AUSENTE_INJUST': 'Inasistencia injustificada',
  'LIBRE': 'Día libre',
};
const ticketReasons = {
  'BAJA_PRODUCTIVIDAD': 'Baja productividad',
  'INASISTENCIA_INJUSTIFICADA': 'Inasistencia injustificada',
  'OTRO': 'Otro incumplimiento',
};
const ticketLevels = ['Advertencia verbal', 'Advertencia escrita', 'Advertencia final'];
const offTypes = ['Libre', 'Permiso', 'Vacaciones', 'Compensatorio'];

String formatDay(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String formatTime(DateTime d) => '${formatDay(d)}T${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
DateTime parseDay(String s) => DateTime.tryParse(s) ?? DateTime.now();
String prettyDate(String s) {
  final v=s.split('-');
  return v.length==3?'${v[2]}/${v[1]}/${v[0]}':s;
}
String newId() => 'id_${DateTime.now().microsecondsSinceEpoch}_${_next++}';
int _next=1;

class FieldSpec {
  const FieldSpec(this.key,this.title,{this.kind='text',this.required=false,this.choices=const {},this.long=false});
  final String key,title,kind;
  final bool required,long;
  final Map<String,String> choices;
}
const generalSpecs = <String,List<FieldSpec>>{
  'operators': [
    FieldSpec('code','Ficha o código'),FieldSpec('name','Nombre completo',required:true),
    FieldSpec('category','Categoría',kind:'choice',choices:{'Mula':'Mula','Grúa':'Grúa','Montacargas':'Montacargas'},required:true),
    FieldSpec('active','Activo',kind:'bool'),FieldSpec('notes','Observaciones',long:true),
  ],
  'assets': [
    FieldSpec('code','Código del equipo',required:true),
    FieldSpec('category','Tipo',kind:'choice',required:true,choices:{'Mula':'Mula','Grúa':'Grúa','Montacargas':'Montacargas'}),
    FieldSpec('description','Descripción',long:true),
  ],
  'tickets': [
    FieldSpec('date','Fecha',kind:'date',required:true),FieldSpec('operatorId','Operador',kind:'operator',required:true),
    FieldSpec('reason','Infracción',kind:'choice',required:true,choices:ticketReasons),
    FieldSpec('level','Nivel de advertencia',kind:'choice',required:true,choices:{'Advertencia verbal':'Verbal','Advertencia escrita':'Escrita','Advertencia final':'Final'}),
    FieldSpec('status','Estado',kind:'choice',required:true,choices:{'ABIERTO':'Abierto','CERRADO':'Cerrado','ESCALADO':'Escalado','ANULADO':'Anulado'}),
    FieldSpec('supervisor','Supervisor',required:true),FieldSpec('expected','Productividad objetivo',kind:'number'),
    FieldSpec('actual','Productividad obtenida',kind:'number'),FieldSpec('description','Descripción',required:true,long:true),
  ],
  'daysOff': [
    FieldSpec('date','Fecha',kind:'date',required:true),FieldSpec('operatorId','Operador',kind:'operator',required:true),
    FieldSpec('type','Tipo de día libre',kind:'choice',choices:{'Libre':'Libre','Permiso':'Permiso','Vacaciones':'Vacaciones','Compensatorio':'Compensatorio'}),
    FieldSpec('notes','Observaciones',long:true),
  ],
  'faults': [
    FieldSpec('assetId','Equipo',kind:'asset',required:true),FieldSpec('start','Inicio de avería',kind:'datetime',required:true),
    FieldSpec('end','Fin de avería (vacío si sigue fuera)',kind:'datetime'),
    FieldSpec('description','Descripción de avería',required:true,long:true),
    FieldSpec('notes','Solución / observaciones',long:true),
  ],
  'holidays': [
    FieldSpec('date','Fecha del feriado',kind:'date',required:true),
    FieldSpec('name','Nombre del feriado',required:true),
  ],
};
const labels = {
  'operators':'Operadores', 'assets':'Equipos', 'attendance':'Asistencia',
  'tickets':'Infracciones', 'daysOff':'Días libres','schedules':'Programación',
  'meals':'Comidas', 'faults':'Averías', 'holidays':'Feriados',
};
