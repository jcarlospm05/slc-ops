import 'package:flutter/foundation.dart';
import 'catalog.dart';
import 'database.dart';
import 'security.dart';

class OpsController extends ChangeNotifier {
  final LocalDatabase database=LocalDatabase();
  Map<String,List<Map<String,dynamic>>> records={for(final e in entities)e:[]};
  bool busy=true;
  String? error;
  Future<void> initialize()async {
    try{await refresh();}catch(e){error=e.toString();}finally{busy=false;notifyListeners();}
  }
  Future<void> refresh()async{
    records=await database.snapshot();error=null;notifyListeners();
  }
  List<Map<String,dynamic>> items(String entity)=>records[entity]??[];
  List<Map<String,dynamic>> get activeOperators=>items('operators').where((r)=>r['active']!=false).toList()..sort((a,b)=>'${a['name']}'.compareTo('${b['name']}'));
  String operatorName(Object? id){for(final r in items('operators')){if(r['id']==id)return '${r['name']}';}return 'Operador no registrado';}
  String assetName(Object? id){for(final r in items('assets')){if(r['id']==id)return '${r['code']}';}return 'Sin equipo';}
  Future<void> put(String entity,Map<String,dynamic> data)async{
    if(entity!='operators' && entity!='assets' && entity!='holidays'){
      final op=data['operatorId'];
      if(op!=null && !items('operators').any((o)=>o['id']==op))throw const DataValidationException('Operador inexistente');
    }
    if(data['assetId']!=null && data['assetId'].toString().isNotEmpty && !items('assets').any((a)=>a['id']==data['assetId'])){
      throw const DataValidationException('Equipo inexistente');
    }
    await database.put(entity,data);await refresh();
  }
  Future<void> remove(String entity,String id)async{await database.remove(entity,id);await refresh();}
  Future<void> replaceMeals(String date,String type,List<String> selected,String note) async{
    final holidays=items('holidays').map((x)=>'${x['date']}');
    if(type=='ALMUERZO'&&!isLunchAllowed(date,holidays))throw const DataValidationException('Almuerzo solo sábados, domingos y feriados');
    await database.replaceMeals(date,type,selected,note);await refresh();
  }
  Future<void> importAll(Map<String,List<Map<String,dynamic>>> data)async{await database.restore(data);await refresh();}
}
