# Generar APK instalable de ControlOPS

## Estado
El código está preparado para compilación, **pero no hay un APK compilado ni validado**. No afirmar que esta app ya fue ejecutada en Android. En el entorno de ChatGPT de esta sesión faltan Flutter y Android SDK y las descargas externas están bloqueadas.

## Opción 1: GitHub Actions (sin Flutter en tu PC)
1. Crear un **repositorio privado exclusivo** para ControlOPS-Android en GitHub.
2. Subir los archivos y carpetas del proyecto a la raíz del repositorio, preservando `.github/workflows/android-apk.yml`.
3. Ir a Actions > Compilar ControlOPS Android APK > Run workflow (o hacer push a main).
4. Tras un build exitoso, abrir la ejecución y descargar el artifact `ControlOPS-Android-APK-debug`.
5. Descomprimir el artifact, copiar `app-debug.apk` al teléfono e instalarlo.

Es un APK **de pruebas**, firmado con una clave de debug que normalmente no se utiliza para distribución. Se requiere probar instalación y funciones antes del uso real. Para actualizaciones coherentes en Android se necesitará mantener una firma de release estable.

## Opción 2: Compilación local
Instalar Flutter + Android SDK + Java 17. Ejecutar `build_apk_windows.bat` en Windows, o `./build_apk_linux.sh` en Linux. El APK aparecerá en `build/app/outputs/flutter-apk/app-debug.apk` después de compilar con éxito.

## Limitaciones
- El workflow no se ha ejecutado; dependencias o errores de compilación pueden exigir correcciones.
- El proyecto Android generará algunos archivos de su plataforma mediante `flutter create`.
- Los datos laborales de SQLite viven solo en el teléfono, no en GitHub ni en Drive.
- GitHub Actions necesita acceso a Internet durante la compilación, pero el APK resultante funciona offline.
