Pruebas unitarias Dart / Flutter para ejecutar con `flutter test`.
No se ejecutaron en este entorno porque no está disponible Flutter SDK.
