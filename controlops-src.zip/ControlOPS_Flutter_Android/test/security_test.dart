import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:controlops_android/core/backup_service.dart';
import 'package:controlops_android/core/catalog.dart';
import 'package:controlops_android/core/security.dart';

void main(){
  test('CSV no ejecuta formulas de Excel',(){
    expect(csvCell('=HYPERLINK("https://attacker.test")'),startsWith('"\'=HYPERLINK'));
    expect(csvCell(' @SUM(1)'),startsWith('"\' @SUM'));
  });
  test('XML escapa contenido de personal',(){
    expect(xmlEscape('<script>&'),equals('&lt;script&gt;&amp;'));
  });
  test('Rechaza categorias arbitrarias',(){
    expect(()=>validatedRecord('operators',{'id':'1','category':'Root'}),throwsA(isA<DataValidationException>()));
  });
  test('Rechaza rango de averia invertido',(){
    expect(()=>validatedRecord('faults',{'id':'1','start':'2026-11-04T12:00','end':'2026-11-03T10:00'}),throwsA(isA<DataValidationException>()));
  });
  test('Solo se permite almuerzo sabado, domingo o feriado',(){
    expect(isLunchAllowed('2026-11-02',const []),isFalse);
    expect(isLunchAllowed('2026-11-07',const []),isTrue);
    expect(isLunchAllowed('2026-11-02',const ['2026-11-02']),isTrue);
  });
  test('Respaldo no reemplaza arrays con valores invalidos',(){
    final body={for(final x in entities)x:<Object>[]};
    body['tickets']=[{'id':'x','reason':'INVALID','level':'Advertencia final','status':'ABIERTO'}];
    final encoded=Uint8List.fromList(utf8.encode(jsonEncode(body)));
    expect(()=>BackupService.parse(encoded),throwsA(isA<DataValidationException>()));
  });
  test('Respaldo acepta la estructura del sitio version 2',(){
    final body={for(final x in entities)x:[]};
    final result=BackupService.parse(Uint8List.fromList(utf8.encode(jsonEncode(body))));
    expect(result.keys,containsAll(entities));
  });
}
