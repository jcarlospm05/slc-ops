# Cómo trabajaremos con los archivos de Google Drive

- Carpeta raíz: `ControlOPS_Flutter_Android`.
- Subcarpetas: `lib/core`, `lib/ui`, `android`, `test`, etc.
- Fuente: un archivo `.dart` por pantalla/servicio. Las siguientes modificaciones deben reemplazar **ese archivo en su ubicación original** en Drive, en lugar de crear nombres `app_final_final_2.dart`.
- `pubspec.yaml` administra las dependencias. Al agregar alguna, volver a ejecutar `flutter pub get`.
- `README.md` contiene instrucciones y limitaciones.
- `ControlOPS_Flutter_Android_Fuente.zip` es una copia portátil. La edición debe hacerse sobre los archivos expandidos.
- Google Drive no compila Flutter ni convierte los `.dart` en código ejecutable: usar una PC de desarrollo, Git o un servicio CI para crear el APK.
- Los datos personales quedan en SQLite del teléfono. No subir copias de datos laborales al Drive de código.
