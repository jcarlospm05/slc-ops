# ControlOPS Android · revisión de seguridad inicial (no pentest real)

## Revisiones de código

- No se solicitó permiso INTERNET en AndroidManifest.xml.
- SQLite usa sentencias parametrizadas mediante `sqflite`; no concatena entradas del usuario a SQL.
- Se valida tamaño y tipo de campos; la restauración JSON restringe tamaño del archivo, entidad y número de registros, y es transaccional.
- Exportación CSV evita interpretación de fórmulas de Excel. XLSX escribe `inlineStr`, no fórmulas ejecutables.
- DOCX escapa XML y los tickets dibujan texto, sin HTML ejecutable.
- Borrado de personal/equipo impide referencias huérfanas desde registros relacionados.
- Existe un historial de cambios `audit_log` en SQLite, sin protección antimanipulación.

## Riesgos sin resolver y pruebas necesarias

1. **ALTO**: no hay cifrado SQLite ni autenticación en la aplicación; exigir bloqueo biométrico de Android y gestionar acceso del dispositivo.
2. **ALTO**: faltan roles/firmas de supervisor y un registro de infracciones con evidencia inmutable. No tratar avisos como sanciones oficiales automáticamente.
3. **MEDIO**: las exportaciones a Word/Excel/JSON y JPG pueden exponer datos personales al compartirlas; requiere controles de distribución, retención y autorización de empleados.
4. **MEDIO**: no hay sincronización de datos entre teléfonos ni resolución de conflictos (funciona en un dispositivo).
5. **MEDIO**: reconstruir el proyecto en Flutter y ejecutar `flutter analyze`, `flutter test` y pruebas manuales Android; en esta sesión no existe el SDK y no hay confirmación de compilación.
6. **MEDIO**: probar restauración de JSON malicioso o de gran tamaño y compatibilidad Excel/Word en dispositivos reales.
7. **BAJO**: el conteo de reincidencias es calculado al emitir tickets; nuevas correcciones antiguas no recalculan retroactivamente todos los tickets.
8. **BAJO**: validar cruces de asignación en día libre, marcación y tareas (hoy permite registrar conflictos que el supervisor debe revisar).
9. **BAJO**: archivos Android de plantilla se completan con `flutter create`; revisar permisos y Gradle al generar.

**Resultado**: revisión estática preliminar; no se afirma auditoría de penetración ejecutada ni APK probado.
