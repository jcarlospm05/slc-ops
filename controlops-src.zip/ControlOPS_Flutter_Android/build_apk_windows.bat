@echo off
setlocal
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
 echo ERROR: Flutter no esta instalado o no esta en PATH.
 echo Instalar Flutter y Android SDK, luego ejecutar otra vez.
 pause
 exit /b 1
)
call flutter create --platforms=android --project-name controlops_android .
if errorlevel 1 goto fail
call flutter pub get
if errorlevel 1 goto fail
call flutter build apk --debug
if errorlevel 1 goto fail
echo APK listo en build\app\outputs\flutter-apk\app-debug.apk
pause
exit /b 0
:fail
echo ERROR: La compilacion fallo. Revisar la salida de la consola.
pause
exit /b 1
