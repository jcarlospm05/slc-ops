# Historial de desarrollo

## v0.1.0 · 2026-11-03
- Primera migración de ControlOPS Web 2 hacia Flutter Android.
- SQLite local con auditoría; sin servidores ni cuenta de usuario.
- Operadores, equipos, asistencia, infracciones, días libres, programación, comidas, averías, feriados.
- Reportes Word/Excel/CSV con gráficos, tickets JPG y respaldos JSON.
- Proyecto separado por archivos editables y archivado en Google Drive.
- Advertencia: fuente NO compilada ni probada en Android en esta entrega.

### Prioridades para siguiente iteración
1. Compilar en Android real, ejecutar `flutter analyze`, `flutter test`, y corregir errores observados.
2. Pruebas reales de XLSX/DOCX/JPG e importación del respaldo de ControlOPS Web.
3. Garantizar protección contra conflictos de día libre/programación/asistencia.
4. Implementar acceso por PIN/biometría y exportaciones protegidas para datos de personal.
5. Adjuntar fotos/evidencia a averías y tickets y firma de supervisor.
6. Crear APK firmado e implementar CI/versiones; pruebas en teléfonos del departamento.
