El codigo fuente Android esta incluido, pero el wrapper ejecutable (gradlew y gradle-wrapper.jar) y los recursos generados por Flutter no se incluyen para evitar archivos obsoletos.
En una PC con Flutter SDK y Android SDK ejecute desde la raiz:
  flutter create --platforms=android --project-name controlops_android .
  flutter pub get
  flutter run
  flutter build apk --release
Este comando regenera/completa el armazon Android. Revise los permisos de AndroidManifest.xml; ControlOPS no debe agregar INTERNET.
NO hay APK precompilado en esta entrega.
