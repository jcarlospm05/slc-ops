#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v flutter >/dev/null; then
  echo 'Flutter no instalado o no esta en PATH.' >&2
  exit 1
fi
flutter create --platforms=android --project-name controlops_android .
flutter pub get
flutter build apk --debug
echo 'APK: build/app/outputs/flutter-apk/app-debug.apk'
